#!/usr/bin/env python

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import pi
from moveit_commander.conversions import pose_to_list

def object(timeout):
	start = rospy.get_time()
	seconds = rospy.get_time()
	while (seconds - start < timeout) and not rospy.is_shutdown():
	  # Test if the box is in attached objects
	  attached_objects = scene.get_attached_objects([box_name])
	  is_attached = len(attached_objects.keys()) > 0

	  # Test if the box is in the scene.
	  # Note that attaching the box will remove it from known_objects
	  is_known = box_name in scene.get_known_object_names()

	  # Test if we are in the expected state
	  #if (box_is_attached == is_attached) and (box_is_known == is_known):
	    #return True

	  # Sleep so that we give other threads time on the processor
	  rospy.sleep(0.1)
	  seconds = rospy.get_time()

	# If we exited the while loop without returning then we timed out
	return False

moveit_commander.roscpp_initialize(sys.argv)
rospy.init_node("move_group_python",anonymous=True)

robot = moveit_commander.RobotCommander(robot_description = "husky1/robot_description")

scene = moveit_commander.PlanningSceneInterface("husky1")

group_name = "arm"
move_group = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = group_name)

planning_frame = move_group.get_planning_frame()
print "====>:%s"%planning_frame

#eef_link = move_group.get_end_effector_link()
eef_link = "wrist_3_link"
print "===>:%s"%eef_link

group_names = robot.get_group_names()
print "===>:",robot.get_group_names()

print "=========== printing robot current states"
print robot.get_current_state()
print ""

#joint_goal = move_group.get_current_joint_values()
#joint_goal[0] = 0
#joint_goal[1] = -pi/4
#joint_goal[2] = 0
#joint_goal[3] = -pi/2
#joint_goal[4] = 0
#joint_goal[5] = pi/3

#move_group.go(joint_goal, wait=True)
#move_group.stop()


box_pose = geometry_msgs.msg.PoseStamped()
box_pose.header.frame_id = robot.get_planning_frame()
box_pose.pose.orientation.w = 1.0
box_pose.pose.position.y = -0.0709
box_pose.pose.position.x = 0.596 + 0.32
box_pose.pose.position.z = 0.843
box_name = "box"
scene.add_box("table", p, (0.4, 0.4, 0.6))
object(5)

grasping_group = 'gripper'
#touch_links = robot.get_link_names(group=grasping_group)
touch_links = ["wrist_3_link"]
print("touch_links====>",touch_links)
scene.attach_box(eef_link, box_name, touch_links=touch_links)
object(20)

scene.remove_attached_object(eef_link, name=box_name)
scene.remove_world_object(box_name)
object(5)


