#! /usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PoseWithCovarianceStamped
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu
from math import pi
import math

theta1 = 0.0
theta2 = 0.0
theta3 = 0.0
x_1 = 0.0


def robot1newOdom(msg):
    global theta1
    rot_q = msg.orientation
    (roll, pitch, theta1) = euler_from_quaternion ([rot_q.x, rot_q.y, rot_q.z, rot_q.w])
    # print theta1

def robot2newOdom(msg):
    global theta2
    rot_q = msg.orientation
    (roll, pitch, theta2) = euler_from_quaternion ([rot_q.x, rot_q.y, rot_q.z, rot_q.w])
    # print theta2

def robot3newOdom(msg):
    global theta3
    rot_q = msg.orientation
    (roll, pitch, theta3) = euler_from_quaternion ([rot_q.x, rot_q.y, rot_q.z, rot_q.w])
    # print theta3

def odom1(msg):
    global x_1
    x_1 = msg.twist.twist.linear.x





rospy.init_node('move_robot')
rate = rospy.Rate(10)
sub_1 = rospy.Subscriber("/robot1/imu/data", Imu, robot1newOdom)
sub_2 = rospy.Subscriber("/robot2/imu/data", Imu, robot2newOdom)
sub_3 = rospy.Subscriber("/robot3/imu/data", Imu, robot3newOdom)
sub_4 = rospy.Subscriber("/robot1/odom", Odometry, odom1)

pub_1 = rospy.Publisher("/robot1/cmd_vel", Twist, queue_size=1)
pub_2 = rospy.Publisher("/robot2/cmd_vel", Twist, queue_size=1)
pub_3 = rospy.Publisher("/robot3/cmd_vel", Twist, queue_size=1)
msg_1 = Twist()
msg_2 = Twist()
msg_3 = Twist()

while not rospy.is_shutdown():
    r2_er_yaw = abs(theta1 - theta2)
    r2_er_yaw_deg = r2_er_yaw * (180/pi)
    r3_er_yaw = abs(theta1 - theta3)
    r3_er_yaw_deg = r3_er_yaw * (180/pi)
    print(r2_er_yaw_deg,r3_er_yaw_deg)

    msg_1.linear.x = -0.3

    msg_2.linear.x = x_1 * math.cos(r2_er_yaw_deg)
    msg_2.linear.y = x_1 * math.sin(r2_er_yaw_deg)

    msg_3.linear.x = -x_1 * math.cos(r3_er_yaw_deg)
    msg_3.linear.y = -x_1 * math.sin(r3_er_yaw_deg)

    pub_1.publish(msg_1)
    pub_2.publish(msg_2)
    pub_3.publish(msg_3)

    rate.sleep()
