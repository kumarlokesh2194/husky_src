#!/usr/bin/env python

import rospy
from moveit_msgs.srv import GetStateValidityRequest, GetStateValidity
from moveit_msgs.msg import RobotState
from sensor_msgs.msg import JointState
import random


class StateValidity():
    def __init__(self):
        # subscribe to joint joint states
        rospy.Subscriber("joint_states", JointState, self.jointStatesCB, queue_size=1)
        # prepare service for collision check
        self.sv_srv = rospy.ServiceProxy('/check_state_validity', GetStateValidity)
        # wait for service to become available
        self.sv_srv.wait_for_service()
        rospy.loginfo('service is avaiable')
        # prepare msg to interface with moveit
        self.rs = RobotState()
	# self.cs = ContactInformation()
        self.rs.joint_state.name = ['elbow_joint', 'shoulder_lift_joint', 'shoulder_pan_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']
	# self.rs.joint_state.position = [random.uniform(-3,3.3), random.uniform(-3,3),random.uniform(-3,3),random.uniform(-3,3),random.uniform(-3,3),random.uniform(-3,3)]
        self.rs.joint_state.position = [0,0,0,0,0,0]
        self.joint_states_received = False


    def checkCollision(self):
        '''
        check if robotis in collision
        '''
        if self.getStateValidity().valid:
            rospy.loginfo('robot not in collision, all ok!')
        else:
            rospy.logwarn('robot in collision')
        print self.rs.joint_state.position


    def jointStatesCB(self, msg):
        '''
        update robot state
        '''
	#self.rs.joint_state.position = [msg.position[0], msg.position[5], msg.position[6], msg.position[7], msg.position[8], msg.position[9]]
	self.rs.joint_state.position = [8.56535284130544e-05, -0.4854078790003607, -5.422004476507425e-05, -1.5707053553946633, -4.30677140164093e-05, 1.047128146632578]
        #self.rs.joint_state.position = [random.uniform(-3,3), random.uniform(-3,3),random.uniform(-3,3),random.uniform(-3,3),random.uniform(-3,3),random.uniform(-3,3)]
        self.joint_states_received = True


    def getStateValidity(self, group_name='arm', constraints=None):
        '''
        Given a RobotState and a group name and an optional Constraints
        return the validity of the State
        '''
        gsvr = GetStateValidityRequest()
        gsvr.robot_state = self.rs
        gsvr.group_name = group_name
        if constraints != None:
            gsvr.constraints = constraints
        result = self.sv_srv.call(gsvr)
        return result


    def start_collision_checker(self):
        while not self.joint_states_received:
            rospy.sleep(0.1)
        rospy.loginfo('joint states received! continue')
        self.checkCollision()
        rospy.spin()


if __name__ == '__main__':
    rospy.init_node('collision_checker_node', anonymous=False)
    for i in range(0,10):
    	collision_checker_node = StateValidity()
    	collision_checker_node.start_collision_checker()

