#! /usr/bin/env python

import rospy
from geometry_msgs.msg import Twist

rospy.init_node('move_robot')
rate = rospy.Rate(10)

pub_cmd_vel = rospy.Publisher('/robot2/husky_velocity_controller/cmd_vel', Twist, queue_size=1)
move_msg = Twist()
move_msg.linear.x = 0.2


while not rospy.is_shutdown():
    pub_cmd_vel.publish(move_msg)
    rate.sleep()
