    
def Random_Walk_Bridge(angle_ref = None,angle = None): 
    #point_bridge = 2 * point - point_ref
    angle_bridge = 2 * angle - angle_ref
    return angle_bridge
    

