#! /usr/bin/env python
import rospy
from sensor_msgs.msg import Imu
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
from geometry_msgs.msg import Point, Twist
from math import atan2
import numpy as np
from numpy import array
from geometry_msgs.msg import PoseStamped
from gazebo_msgs.msg import ModelStates
import time
import pose_
import sys
import copy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from geometry_msgs.msg import PoseStamped
from math import pi
from gazebo_ros_link_attacher.srv import Attach, AttachRequest, AttachResponse
from trajectory_msgs.msg import JointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from std_msgs.msg import Header
from numpy import array
from std_srvs.srv import Empty
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from sensor_msgs.msg import PointCloud2
import time
from numpy import array
# from marker import TrajectoryInteractiveMarkers



# def newOdom(msg):
#     global theta
#     rot_q = msg.orientation
#     (roll, pitch, theta) = euler_from_quaternion ([rot_q.x, rot_q.y, rot_q.z, rot_q.w])

def callback1(msg):
    global flag
    global time_taken1
    time1 = time.time()
    while time_taken1 < 20:
        pub1.publish(msg)
        time2 = time.time()
        time_taken1 = time2 - time1
        print time_taken1
    # sv_srv1 = rospy.ServiceProxy("/robot1/clear_octomap",Empty)
    # sv_srv1.call()
    # time_taken1 = 0


    rospy.sleep(3)
    flag = 0

def callback2(msg):
    global flag
    global time_taken2
    time1 = time.time()
    while time_taken2 < 20:
        pub2.publish(msg)
        time2 = time.time()
        time_taken2 = time2 - time1
        print time_taken2
    # sv_srv2 = rospy.ServiceProxy("/robot2/clear_octomap",Empty)
    # sv_srv2.call()
    # time_taken2 = 0


    rospy.sleep(3)
    flag = 0

def newxyz(msg):
    global x_1
    global y_1
    global theta_1
    global x_2
    global y_2
    global theta_2
    index1 = 0
    index2 = 0
    for i in range(0,len(msg.name)):
        if msg.name[i] == "robot1":
            index1 = i
        elif msg.name[i]=="robot2":
            index2 = i
    rot_q_1 = msg.pose[index1].orientation
    (roll_1, pitch_1, theta_1) = euler_from_quaternion ([rot_q_1.x, rot_q_1.y, rot_q_1.z, rot_q_1.w])
    rot_q_2 = msg.pose[index2].orientation
    (roll_2, pitch_2, theta_2) = euler_from_quaternion ([rot_q_2.x, rot_q_2.y, rot_q_2.z, rot_q_2.w])
    x_1 = msg.pose[index1].position.x
    y_1 = msg.pose[index1].position.y
    x_2 = msg.pose[index2].position.x
    y_2 = msg.pose[index2].position.y
    # print x,y,z,theta

if __name__ == '__main__':
    rospy.init_node ("speed_controller")
    sv_srv1 = rospy.ServiceProxy("/robot1/clear_octomap",Empty)
    sv_srv1.call()
    sv_srv2 = rospy.ServiceProxy("/robot2/clear_octomap",Empty)
    sv_srv2.call()
    x_1 = 0.0
    y_1 = 0.0
    theta_1 = 0.02
    x_2 = 0.0
    y_2 = 0.0
    theta_2 = 0.02
    time_taken1 = 0
    time_taken2 = 0
    flag = 1
    r = rospy.Rate(1)


    # sub = rospy.Subscriber("/robot1/imu/data", Imu, newOdom)
    sub = rospy.Subscriber("/gazebo/model_states", ModelStates, newxyz)
    pub_1 = rospy.Publisher("/robot1/cmd_vel",Twist, queue_size=1)
    pub_2 = rospy.Publisher("/robot2/cmd_vel",Twist, queue_size=1)
    speed_1 = Twist()
    speed_2 = Twist()

    r = rospy.Rate(5)
    point_index = 0

    goal_1 = Point()
    goal_2 = Point()
    kp = 0.5
    # kd = 0.1
    # ki = 0.005
    # current_time = 0
    # last_time = 0
    error_yaw_1 = 0
    error_x_1 = 0
    error_y_1 = 0
    error_yaw_2 = 0
    error_x_2 = 0
    error_y_2 = 0
    c = 1
    # error_z = 0
    # prev_error_x = 0
    # prev_error_y = 0
    # prev_error_yaw = 0
    while not rospy.is_shutdown():
        # trajectory_interactive_markers = TrajectoryInteractiveMarkers()
        # current_time = time.time()
        goal_1.x = 7.640
        goal_1.y = 2.029
        error_x_1 = (goal_1.x - x_1)
        error_y_1 = (goal_1.y - y_1)
        yaw_goal_1 = 3.14
        yaw_goal_2 = 3.14
        goal_2.x = 7.740
        goal_2.y = -1.380
        start_yaw_1 = 0
        start_yaw_2 = 0
        error_x_2 = (goal_2.x - x_2)
        error_y_2 = (goal_2.y - y_2)
        error_yaw_1 = yaw_goal_1-theta_1
        error_yaw_2 = yaw_goal_2-theta_2
        # dt = current_time - last_time
        distance_to_goal_1 = np.sqrt(error_x_1*error_x_1 + error_y_1*error_y_1)
        distance_to_goal_2 = np.sqrt(error_x_2*error_x_2 + error_y_2*error_y_2)
        while c==1:
            error_start_yaw_1 = start_yaw_1 - theta_1
            error_start_yaw_2 = start_yaw_2 - theta_2
            speed_1.angular.z = kp * (error_start_yaw_1)
            speed_1.linear.x = 0.0
            speed_1.linear.y = 0.0
            speed_2.angular.z = kp * (error_start_yaw_2)
            speed_2.linear.x = 0.0
            speed_2.linear.y = 0.0
            pub_1.publish(speed_1)
            pub_2.publish(speed_2)
            if abs(error_start_yaw_1) < 0.01 and abs(error_start_yaw_2) < 0.01:
                c = 0

        if distance_to_goal_1 > 0.05:
            speed_1.linear.x = kp * (error_x_1)
            speed_1.linear.y = kp * (error_y_1)
            speed_1.angular.z = 0
        elif distance_to_goal_1<0.05:
            # sub1 = rospy.Subscriber("/robot1/camera/depth/points", PointCloud2, callback1)
            # pub1 = rospy.Publisher("/lokesh1/camera/depth/points", PointCloud2, queue_size = 1000)
            speed_1.linear.x = 0
            speed_1.linear.y = 0
            speed_1.angular.z = kp * error_yaw_1

        if distance_to_goal_2 > 0.05 :
            speed_2.linear.x = kp * (error_x_2)
            speed_2.linear.y = kp * (error_y_2)
            speed_2.angular.z = 0
        elif distance_to_goal_2<0.05:
            # sub2 = rospy.Subscriber("/robot2/camera/depth/points", PointCloud2, callback2)
            # pub2 = rospy.Publisher("/lokesh2/camera/depth/points", PointCloud2, queue_size = 1000)
            speed_2.linear.x = 0
            speed_2.linear.y = 0
            speed_2.angular.z = kp * error_yaw_2

        # #speed.linear.z = kp * (goal.z - z)
        # #prev_error_yaw = error_yaw
        # prev_error_x = error_x
        # prev_error_y = error_y
        # last_time = current_time
        print("error_yaw_1:{} error_x_1:{} error_y_1:{}".format(error_yaw_1,error_x_1,error_y_1))
        print("error_yaw_2:{} error_x_2:{} error_y_2:{}".format(error_yaw_2,error_x_2,error_y_2))
        if abs(error_yaw_1) < 0.01:
            sub1 = rospy.Subscriber("/robot1/camera/depth/points", PointCloud2, callback1)
            pub1 = rospy.Publisher("/lokesh1/camera/depth/points", PointCloud2, queue_size = 1000)
        if abs(error_yaw_2) < 0.01:
            sub2 = rospy.Subscriber("/robot2/camera/depth/points", PointCloud2, callback2)
            pub2 = rospy.Publisher("/lokesh2/camera/depth/points", PointCloud2, queue_size = 1000)
        if abs(error_yaw_1) < 0.005 and abs(error_yaw_2) < 0.005:
            break
        pub_1.publish(speed_1)
        pub_2.publish(speed_2)
        # r.sleep()
