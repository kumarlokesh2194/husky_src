#!  /usr/bin/env python

import rospy
from trajectory_msgs.msg import JointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from std_msgs.msg import Header



def move_camera(point):

	#rospy.init_node("move_arm")
	#rate = rospy.Rate(10)

	#pub_arm_joint = rospy.Publisher("/arm_controller/command", JointTrajectory, queue_size=1)
	move_arm_joint = JointTrajectory()
	move_arm_position = JointTrajectoryPoint()
	move_arm_joint.joint_names = ["kinect_frame_joint"]
	move_arm_position.positions = point
	move_arm_position.velocities = [.1]
	move_arm_position.accelerations = [.1]
	move_arm_position.effort = [0]
	move_arm_position.time_from_start.secs = 4
	move_arm_position.time_from_start.nsecs = 4

	move_arm_joint.points = [move_arm_position]
	return move_arm_joint



if __name__ == "__main__":

	rospy.init_node("move_arm")
	#rate = rospy.Rate(10)
	pub_arm_joint = rospy.Publisher("/kinect_joint_controller/command", JointTrajectory, queue_size=1)
	
	points = ([0.5])
	
	while not rospy.is_shutdown():
		msg = move_camera(points)

  		pub_arm_joint.publish(msg)
		rospy.sleep(0.1)
