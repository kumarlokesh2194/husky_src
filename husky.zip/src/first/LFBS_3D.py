#!/usr/bin/env python


import numpy as np
import Levy_Random_Walk
import Random_Walk_Bridge
from state_validity import StateValidity
import random
from math import pi
import rospy
from moveit_msgs.srv import GetStateValidityRequest, GetStateValidity
from moveit_msgs.msg import RobotState
from sensor_msgs.msg import JointState

## Random Walk Parameters Initialization
min_ = -pi
max_ =  pi
collision_check = 0
n_obs = 1
step_size = 5
n_samples = 50
k = 1
sampled_points = []
global sh_lift,sh_pan,elbow,w_1,w_2,w_3
rospy.init_node('collision', anonymous=False)
collision = StateValidity()
while k <= n_samples:
    #-----Random Test Object Position-----

     #dx = 100 * random.uniform(0,1)
     #dy = 100 * random.uniform(0,1)
     #dz = 70 * random.uniform(0,1)
     sh_pan = random.uniform(-pi,pi)
     sh_lift = random.uniform(-pi,pi)
     elbow = random.uniform(-pi,pi)
     w_1 = random.uniform(-pi,pi)
     w_2 = random.uniform(-pi,pi)
     w_3 = random.uniform(-pi,pi)
     #point_ref = np.array([dx,dy,dz])
     angle_ref = np.array([sh_pan,sh_lift,elbow,w_1,w_2,w_3])
     #collision_check = collision_check + 1
     collision_1 = 0
     collision_1 = collision.start_collision_checker()
     print ("collision_1",collision_1)
     if collision_1:
         point = np.array([sh_pan, sh_lift, elbow, w_1, w_2, w_3])
         #n_steps[k] = 0
         while True:
             #n_steps[k] = n_steps[k] + 1
             prev_point = point
             angle = Levy_Random_Walk.Levy_Random_Walk(prev_point,step_size,min_,max_)
             #dx = point[0]
             #dy = point[1]
             #dz = point[2]
             sh_pan = angle[0]
             sh_lift = angle[1]
             elbow = angle[2]
             w_1 = angle[3]
             w_2 = angle[4]
             w_3 = angle[5]
             #collision_check = collision_check + 1
             collision_2 = 0
             collision_2 = collision.start_collision_checker()
	     print ("collision_2",collision_2)
             if collision_2 == 0:
                 logic = 0
		 c_flag = collision.start_collision_checker()
                 logic = logic + c_flag		    
                 print("logic", logic)
                 if logic == 0:
                     angle_bridge = Random_Walk_Bridge.Random_Walk_Bridge(angle_ref,angle)
                     #dx = point_bridge[0]
                     #dy = point_bridge[1]
                     #dz = point_bridge[2]
	             sh_pan = angle_bridge[0]
	             sh_lift = angle_bridge[1]
	             elbow = angle_bridge[2]
	             w_1 = angle_bridge[3]
	             w_2 = angle_bridge[4]
	             w_3 = angle_bridge[5]
                     logic_bridge = 0
          	     f_flag = collision.start_collision_checker()
                     logic_bridge = logic_bridge + f_flag
		     print("bridge", logic_bridge)
                     if logic_bridge != 0:
                        #dx = point[0]
	         	#dy = point[1]
			#dz = point[2]
			sh_pan = angle[0]
			sh_lift = angle[1]
			elbow = angle[2]
			w_1 = angle[3]
			w_2 = angle[4]
			w_3 = angle[5]
			sampled_points.append(angle)
                        
                        k = k + 1
			print("k========>",k)
                        break
                     else:
			break
print("sampled======>",sampled_points)
rospy.sleep(0.1)





