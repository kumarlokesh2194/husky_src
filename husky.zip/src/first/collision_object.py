#! /usr/bin/env python

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from geometry_msgs.msg import PoseStamped

moveit_commander.roscpp_initialize(sys.argv)
rospy.init_node('move_group_python', anonymous=True)


robot = moveit_commander.RobotCommander()
scene = moveit_commander.PlanningSceneInterface()
# group = moveit_commander.MoveGroupCommander('arm')
# diaplay_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path',moveit_msgs.msg.DisplayTrajectory,queue_size=1)


# pose_target = geometry_msgs.msg.Pose()
# pose_target.orientation.w = 0.0
# pose_target.position.x = 0.6
# pose_target.position.y = 0.11
# pose_target.position.z = 0.45
# group.set_pose_target(pose_target)
#
rospy.sleep(2)

p1 = PoseStamped()
p1.header.frame_id = "base_link"
p1.pose.position.x = 0.1
p1.pose.position.y = 5.8
p1.pose.position.z = 0.7
scene.add_box("rod1", p1, (0.05, 0.05, 1))
rospy.sleep(2)
p2 = PoseStamped()
p2.header.frame_id = "base_link"
p2.pose.position.x = 0.1
p2.pose.position.y = 6.2
p2.pose.position.z = 0.7
scene.add_box("rod2", p2, (0.05, 0.05, 1))
rospy.sleep(2)
p3 = PoseStamped()
p3.header.frame_id = "base_link"
p3.pose.position.x = 0.1
p3.pose.position.y = 6.4
p3.pose.position.z = 0.7
scene.add_box("rod3", p3, (0.05, 0.05, 1))



#plan1 = group.plan()

rospy.sleep(5)
# group.go(wait = True)

moveit_commander.roscpp_shutdown()
