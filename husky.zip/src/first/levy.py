import numpy as np
import scipy.special
from math import pi
import random
    
def levy(n = None,m = None,beta = None): 
    # This function implements Levy's flight.
    
    # For more information see
#'Multiobjective cuckoo search for design optimization Xin-She Yang, Suash Deb'.
    
    # Coded by Hemanth Manjunatha on Nov 13 2015.
    
    # Input parameters
# n     -> Number of steps
# m     -> Number of Dimensions
# beta  -> Power law index  # Note: 1 < beta < 2
    
    # Output
# z     -> 'n' levy steps in 'm' dimension
    
    num = scipy.special.gamma(1 + beta) * np.sin(pi * beta / 2)
    
    den = scipy.special.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2)
    
    sigma_u = (num / den) ** (1 / beta)
    
    u = np.random.normal(0,sigma_u ** 2,[n,m])
    v = np.random.normal(0,1,[n,m])
    z = u / (np.abs(v) ** (1 / beta))
    return z[0]
    

a = levy(1,1,1.9)
print(a)
