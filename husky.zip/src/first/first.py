#! /usr/bin/env python

import rospy
from geometry_msgs.msg import Twist

rospy.init_node('move_robot')
rate = rospy.Rate(10)

pub_cmd_vel1 = rospy.Publisher("/robot1/cmd_vel", Twist, queue_size=1)
pub_cmd_vel2 = rospy.Publisher("/robot2/cmd_vel", Twist, queue_size=1)
move_msg1 = Twist()
# move_msg1.angular.z = 1
move_msg1.linear.x = -0.3
# move_msg1.linear.y = -0.3
move_msg2 = Twist()
move_msg2.angular.z = 1
# move_msg2.linear.x = 0.3
# move_msg2.linear.y = 0.3


while not rospy.is_shutdown():
    pub_cmd_vel1.publish(move_msg1)
    pub_cmd_vel2.publish(move_msg2)
    rate.sleep()
