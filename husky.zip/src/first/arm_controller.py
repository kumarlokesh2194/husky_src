#!  /usr/bin/env python

import rospy
from trajectory_msgs.msg import JointTrajectory 
from trajectory_msgs.msg import JointTrajectoryPoint


rospy.init_node("move_arm")
rate = rospy.Rate(10)

pub_arm_joint = rospy.Publisher("/arm_controller/command", JointTrajectory, queue_size=1)
pub_arm_positions = rospy.Publisher("/arm_controller/command", JointTrajectoryPoint, queue_size=1)
move_arm_joint = JointTrajectory()
move_arm_joint_positions = JointTrajectoryPoint()
move_arm_joint.joint_names = ["shoulder_pan_joint","shoulder_lift_joint","elbow_joint","wrist_1_joint","wrist_2_joint","wrist_3_joint"]
move_arm_joint_positions.positions = [0.8,-0.75,1.2,0.0,0.0,0.0]
#move_arm_joint_positions.velocities = [0.1,0.1,0.1,0.1,0.1,0.1]
#move_arm_joint_positions.accelerations = [0.1,0.1,0.1,0.1,0.1,0.1]
#move_arm_joint_positions.effort = [0]
#move_arm_joint_positions.time_from_start.secs = 2
#move_arm_joint_positions.time_from_start.nsecs = 2


while not rospy.is_shutdown():
    pub_arm_joint.publish(move_arm_joint)
    pub_arm_positions.publish(move_arm_joint_positions)
    rate.sleep()

