#! /usr/bin/env python

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from geometry_msgs.msg import PoseStamped
from math import pi
from gazebo_ros_link_attacher.srv import Attach, AttachRequest, AttachResponse
from trajectory_msgs.msg import JointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from std_msgs.msg import Header
from numpy import array
from std_srvs.srv import Empty
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from sensor_msgs.msg import PointCloud2
import time
from numpy import array

def callback1(msg):
    global flag
    global time_taken
    time1 = time.time()
    while time_taken < 1:
        pub1.publish(msg)
        time2 = time.time()
        time_taken = time2 - time1
        print time_taken
    # sv_srv = rospy.ServiceProxy("/clear_octomap",Empty)
    # sv_srv.call()

    rospy.sleep(3)
    flag = 0

def callback2(msg):
    global flag
    global time_taken
    time1 = time.time()
    while time_taken < 1:
        pub2.publish(msg)
        time2 = time.time()
        time_taken = time2 - time1
        print time_taken
    # sv_srv = rospy.ServiceProxy("/clear_octomap",Empty)
    # sv_srv.call()

    rospy.sleep(3)
    flag = 0





def move():
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('move_group_python', anonymous=True)


    robot1 = moveit_commander.RobotCommander(robot_description = "husky1/robot_description")
    scene1 = moveit_commander.PlanningSceneInterface("husky1")
    group1 = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = "arm")

    #robot2 = moveit_commander.RobotCommander(robot_description = "robot2/robot_description")
    #scene2 = moveit_commander.PlanningSceneInterface("robot2")
    #group2 = moveit_commander.MoveGroupCommander(robot_description = "robot2/robot_description", ns = "robot2", name = "arm")
    # group1 = moveit_commander.MoveGroupCommander('gripper')
    # diaplay_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path',moveit_msgs.msg.DisplayTrajectory,queue_size=1)

    # for quat in point:
    pose_target1 = geometry_msgs.msg.Pose()
        # quat = quaternion_from_euler(2.737, -0.006, 1.575)
    pose_target1.orientation.w = 1
        # pose_target.orientation.x = quat[0]
        # pose_target.orientation.y = quat[1]
        # pose_target.orientation.z = quat[2]
    pose_target1.position.x = 0.119
    pose_target1.position.y = 0.036
    pose_target1.position.z = 0.776

    # for quat in point:
    #pose_target2 = geometry_msgs.msg.Pose()
        # quat = quaternion_from_euler(2.737, -0.006, 1.575)
    #pose_target2.orientation.w = 1
        # pose_target.orientation.x = quat[0]
        # pose_target.orientation.y = quat[1]
        # pose_target.orientation.z = quat[2]
    #pose_target2.position.x = 0.119
    #pose_target2.position.y = 0.036
    #pose_target2.position.z = 0.776

    group1.set_pose_target(pose_target1)
    #group2.set_pose_target(pose_target2)
    sv_srv1 = rospy.ServiceProxy("/husky1/clear_octomap",Empty)
    sv_srv1.call()

    #sv_srv2 = rospy.ServiceProxy("/robot2/clear_octomap",Empty)
    #sv_srv2.call()


    group1.plan()
    #group2.plan()
    group1.plan()
    #group2.plan()
    group1.plan()
    #group2.plan()
    group1.plan()
    #group2.plan()
    group1.plan()
    #group2.plan()

    # joint = group.get_current_joint_values()
    # print(joint)

    # joint_goal = group.get_current_joint_values()
    # print(joint_goal)
    #joint_goal[0] = 0
    #joint_goal[1] = -pi/3
    #joint_goal[2] = 0
    #joint_goal[3] = -pi/2
    #joint_goal[4] = 0
    #joint_goal[5] = pi/3
	#
    # joint_gripper = [0.027540172282155825]
    # group1.go(joint_gripper, wait=True)
    # group1.stop()
	#
    # joint_goal = [2.5594785236635915, -1.9044956668180246, 1.541772687413668, 0.3699905244102549, 1.001448606750577, -0.008009692750515862]
    # group.go(joint_goal, wait=True)
    # #print joint_goal[0]
    # group.stop()
	#
    # joint_goal = [2.79452589571766, -1.4582218093131145, 1.1573683469188523, 0.30733322827510223, 1.2364900879959655, -0.006217819672323821]
    # group.go(joint_goal, wait=True)
    # print joint_goal[0]
    # group.stop()
	#
    # joint_gripper = [0.45]
    # group1.go(joint_gripper, wait=True)
    # group1.stop()
	#
    # attach()

    #joint_goal = [2.540440584695485, -1.9981821130828583, 1.8972598416743387, 0.10042318783493442, 0.9684531626420737, -0.0006339319476427656]
    #group.go(joint_goal, wait=True)
    #print joint_goal[0]
    #group.stop()

    #joint_gripper = [0.027540172282155825]
    #group1.go(joint_gripper, wait=True)
    #group1.stop()

    #detach()

    #rospy.sleep(1)

    #p = PoseStamped()
    #p.header.frame_id = robot.get_planning_frame()
    # p.header.frame_id = "base_link"
    #p.pose.position.x = 1.0717
    #p.pose.position.y = -0.0171
    #p.pose.position.z = 0.6
    #p.pose.orientation.w = 1.0
    #scene.add_box("table", p, (1, 1, 0.01))

    #plan1 = group.plan()

    #rospy.sleep(5)
    #group.go(wait = True)

    moveit_commander.roscpp_shutdown()

if __name__ == '__main__':
    move()
    time_taken = 0
    flag = 1
    r = rospy.Rate(1)
    sub1 = rospy.Subscriber("/husky1/camera/depth/points", PointCloud2, callback1)
    pub1 = rospy.Publisher("/lokesh1/depth/points", PointCloud2, queue_size = 1)
    #sub2 = rospy.Subscriber("/robot2/camera/depth/points", PointCloud2, callback2)
    #pub2 = rospy.Publisher("/lokesh2/depth/points", PointCloud2, queue_size = 1)
    while not rospy.is_shutdown():
        r.sleep()
    #rate = rospy.Rate(10)
    # pub_arm_joint1 = rospy.Publisher("/robot1/arm_controller/command", JointTrajectory, queue_size=1)
    # pub_arm_joint2 = rospy.Publisher("/robot2/arm_controller/command", JointTrajectory, queue_size=1)
    # pub_gripper_joint1 = rospy.Publisher("/robot1/gripper_controller/command", JointTrajectory, queue_size=1)
    # pub_gripper_joint2 = rospy.Publisher("/robot2/gripper_controller/command", JointTrajectory, queue_size=1)
    # # pub_arm_joint3 = rospy.Publisher("/robot3/arm_controller/command", JointTrajectory, queue_size=1)
	#
    # arm_joints =   [[0,0,0,0,0,0],[-0.12673957870912655, -0.41121026152494566, 2.154675607101795, -1.7247966840942774, 1.3976371605053166, 0.0037959267834042237]]
    # gripper_joints = [[0],[0.6783151216755539]]
	#
    # n = 0
    # # l = len(points)
    # for i in arm_joints:
    #     print i
    #     msg_arm = move_arm(i)
    #     print("ccc")
    #     pub_arm_joint1.publish(msg_arm)
    #     pub_arm_joint2.publish(msg_arm)
    #     #pub_gripper_joint1.publish(msg_gripper)
    #     #pub_gripper_joint2.publish(msg_gripper)
    #     # pub_arm_joint3.publish(msg)
    #     #if n == l:
    #     #	rospy.isshutdown()
    #     rospy.sleep(2)
	#
    # for j in arm_joints:
    #     print j
    #     msg_gripper = move_gripper(j)
    #     print("ccc")
    #     pub_gripper_joint1.publish(msg_gripper)
    #     pub_gripper_joint2.publish(msg_gripper)
    #     # pub_arm_joint3.publish(msg)
    #     #if n == l:
    #     #	rospy.isshutdown()
    #     rospy.sleep(2)
