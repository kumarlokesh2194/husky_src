#!/usr/bin/env python

import rospy
from moveit_msgs.srv import GetStateValidityRequest, GetStateValidity
from moveit_msgs.msg import RobotState
from sensor_msgs.msg import JointState
from math import pi
import numpy as np
import random


class StateValidity():
    def __init__(self):
        # subscribe to joint joint states
        #rospy.Subscriber("joint_states", JointState, self.jointStatesCB, queue_size=1)
        # prepare service for collision check
        self.sv_srv = rospy.ServiceProxy('/check_state_validity', GetStateValidity)
        # wait for service to become available
        self.sv_srv.wait_for_service()
        rospy.loginfo('service is avaiable')
        # prepare msg to interface with moveit
        self.rs = RobotState()
	# self.cs = ContactInformation()
        self.rs.joint_state.name = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']
	# self.rs.joint_state.position = [random.uniform(-3,3.3), random.uniform(-3,3),random.uniform(-3,3),random.uniform(-3,3),random.uniform(-3,3),random.uniform(-3,3)]
        self.rs.joint_state.position = [0,0,0,0,0,0]
        self.joint_states_received = False


    def checkCollision(self):
        '''
        check if robotis in collision
        '''
	c_flag = 0
        if self.getStateValidity().valid:
            rospy.loginfo('robot not in collision, all ok!')
	    c_flag = 0
        else:
            rospy.logwarn('robot in collision')
            c_flag = 1
        #print self.rs.joint_state.position
        return c_flag
        


    #def jointStatesCB(self,msg):
       #'''
       #update robot state
       #'''
       #self.rs.joint_state.position = [msg.position[0], msg.position[5], msg.position[6], msg.position[7], msg.position[8], msg.position[9]]
       #self.rs.joint_state.position = [elbow, sh_lift, sh_pan, w_1, w_2, w_3]
       #self.rs.joint_state.position = [np.random.uniform(-pi,pi), np.random.uniform(-pi,pi),np.random.uniform(-pi,pi),np.random.uniform(-pi,pi),np.random.uniform(-pi,pi),np.random.uniform(-pi,pi)]
       #self.joint_states_received = True


    def getStateValidity(self, group_name='arm', constraints=None):
        '''
        Given a RobotState and a group name and an optional Constraints
        return the validity of the State
        '''
        gsvr = GetStateValidityRequest()
        gsvr.robot_state = self.rs
        gsvr.group_name = group_name
        if constraints != None:
            gsvr.constraints = constraints
        result = self.sv_srv.call(gsvr)
        return result


    def start_collision_checker(self):
	from LFBS_3D import elbow,sh_lift,sh_pan,w_1,w_2,w_3
	self.rs.joint_state.position = [sh_pan, sh_lift, elbow, w_1, w_2, w_3]
        #self.rs.joint_state.position = [-2.1708421386902765, -2.1060144070799547, -1.4593113543001623, 2.350785852174953, -2.171122802726611, 2.5979595189649887]
        self.joint_states_received = True
        while not self.joint_states_received:
            rospy.sleep(0.1)
        #rospy.loginfo('joint states received! continue')
        c_flag = self.checkCollision()
        return c_flag
        
        
	



if __name__ == '__main__':
    rospy.init_node('collision_checker_node', anonymous=False)
    collision_checker_node = StateValidity()
    collision_checker_node.start_collision_checker()
    rospy.sleep(0.1)

    
 

