#! /usr/bin/env python

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from geometry_msgs.msg import PoseStamped
from math import pi
from gazebo_ros_link_attacher.srv import Attach, AttachRequest, AttachResponse

def attach(robot,link):
    # rospy.init_node('demo_attach_links')
    rospy.loginfo("Creating ServiceProxy to /link_attacher_node/attach")
    attach_srv = rospy.ServiceProxy('/link_attacher_node/attach',
                                    Attach)
    attach_srv.wait_for_service()
    rospy.loginfo("Created ServiceProxy to /link_attacher_node/attach")

    # Link them
   # rospy.loginfo("Attaching cube1 and cube2")
   # req = AttachRequest()
   # req.model_name_1 = "/"
   # req.link_name_1 = "robotiq_85_left_finger_tip_link"
   # req.model_name_2 = "cube2"
   # req.link_name_2 = "link"

   # attach_srv.call(req)
    # From the shell:
    rospy.loginfo("Attaching cube2 and cube3")
    req = AttachRequest()
    req.model_name_1 = robot
    req.link_name_1 = "robotiq_85_right_finger_tip_link"
    req.model_name_2 = link
    req.link_name_2 = "link"

    attach_srv.call(req)

def detach(robot,link):
    # rospy.init_node('demo_detach_links')
    rospy.loginfo("Creating ServiceProxy to /link_attacher_node/detach")
    attach_srv = rospy.ServiceProxy('/link_attacher_node/detach',
                                    Attach)
    attach_srv.wait_for_service()
    rospy.loginfo("Created ServiceProxy to /link_attacher_node/detach")

    # Link them
    #rospy.loginfo("Detaching cube1 and cube2")
    #req = AttachRequest()
    #req.model_name_1 = "/"
    #req.link_name_1 = "robotiq_85_left_finger_tip_link"
    #req.model_name_2 = "cube2"
    #req.link_name_2 = "link"

    #attach_srv.call(req)
    # From the shell:

    rospy.loginfo("Attaching cube2 and cube3")
    req = AttachRequest()
    req.model_name_1 = robot
    req.link_name_1 = "robotiq_85_right_finger_tip_link"
    req.model_name_2 = link
    req.link_name_2 = "link"

    attach_srv.call(req)

    #rospy.loginfo("Attaching cube3 and cube1")
    #req = AttachRequest()
    #req.model_name_1 = "cube3"
    #req.link_name_1 = "link"
    #req.model_name_2 = "cube1"
    #req.link_name_2 = "link"

    #attach_srv.call(req)


if __name__ == '__main__':
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('move_group_python', anonymous=True)


    robot1 = moveit_commander.RobotCommander(robot_description = "robot1/robot_description")
    scene1 = moveit_commander.PlanningSceneInterface("robot1")
    group1 = moveit_commander.MoveGroupCommander(robot_description = "robot1/robot_description", ns = "robot1", name = "arm")

    robot2 = moveit_commander.RobotCommander(robot_description = "robot2/robot_description")
    scene2 = moveit_commander.PlanningSceneInterface("robot2")
    group2 = moveit_commander.MoveGroupCommander(robot_description = "robot2/robot_description", ns = "robot2", name = "arm")


    #pose_target = geometry_msgs.msg.Pose()
    #pose_target.orientation.w = 0.0
    #pose_target.position.x = 0.6
    #pose_target.position.y = 0.11
    #pose_target.position.z = 0.45
    #group.set_pose_target(pose_target)

    #rospy.sleep(5)

    # joint_goal = group.get_current_joint_values()
    # print(joint_goal)
    #joint_goal[0] = 0
    #joint_goal[1] = -pi/3
    #joint_goal[2] = 0
    #joint_goal[3] = -pi/2
    #joint_goal[4] = 0
    #joint_goal[5] = pi/3

    joint_goal2 = [-0.7010254455953695, 0.27197383686643717, -0.3574383568217818, -3.0692674463536913, -0.870481144105239, -3.132906274386912]
    group2.go(joint_goal2, wait=True)
    robot2 = "robot2"
    link2 = "cube3"
    # attach(robot2,link2)

    # joint_goal2 = [-2.647946102496824, -1.0632586814478273, 1.8597686474925568, -0.7815512717010857, 2.0515581821849556, 0.006598009323740061]
    # group2.go(joint_goal2, wait=True)
    # detach(robot)

    joint_goal1 = [-3.075111022391138, -2.126267251526607, -0.3965363760515862, -0.6159095731383462, 1.4812606912581847, 3.1414323664981807]
    group1.go(joint_goal1, wait = True)
    robot1 = "robot1"
    link1 = "cube6"
    # attach(robot1,link1)



    #rospy.sleep(1)

    #p = PoseStamped()
    #p.header.frame_id = robot.get_planning_frame()
    # p.header.frame_id = "base_link"
    #p.pose.position.x = 1.0717
    #p.pose.position.y = -0.0171
    #p.pose.position.z = 0.6
    #p.pose.orientation.w = 1.0
    #scene.add_box("table", p, (1, 1, 0.01))

    #plan1 = group.plan()

    #rospy.sleep(5)
    #group.go(wait = True)

    moveit_commander.roscpp_shutdown()
