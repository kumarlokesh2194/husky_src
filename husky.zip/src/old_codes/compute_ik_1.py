import rospy
from moveit_msgs.srv import GetPositionIK
from moveit_msgs.srv import GetPositionIKRequest
from moveit_msgs.srv import GetPositionIKResponse
from geometry_msgs.msg import PoseStamped
import moveit_commander
from sensor_msgs.msg import JointState
from moveit_msgs.msg import RobotState
import sys
from moveit_msgs.msg import PositionIKRequest

if __name__ == "__main__":
    rospy.init_node('move_group_python1', anonymous=True)
    rospy.wait_for_service('husky1/compute_ik')
    get_position_ik = rospy.ServiceProxy('husky1/compute_ik', GetPositionIK)

    tf = JointState()
    rs = RobotState()

    tf.name = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']
    tf.position = [0.3597424874760525, -0.09071510575062486, 1.2647727118930594, -1.1809014937567401, -1.9786178939099057, -0.0024480116089993123]
    rs.joint_state = tf


    target = PoseStamped()
    target.header.frame_id = 'base_link'
    x, y, z = -7.48, 5.541, 0.366
    target.pose.position.x = x
    target.pose.position.y = y
    target.pose.position.z = z
    qx, qy, qz, qw = 0.0, 0.0, 0.0, 1.0
    target.pose.orientation.x = qx
    target.pose.orientation.y = qy
    target.pose.orientation.z = qz
    target.pose.orientation.w = qw

    service_request = PositionIKRequest()
    service_request.group_name = 'arm'
    service_request.pose_stamped = target
    service_request.robot_state = rs
    # service_request.timeout.secs= 0.1
    service_request.avoid_collisions = True

    rospy.loginfo("Request = {0}".format(service_request))
    print("calling service")

    resp = get_position_ik(service_request)
    rospy.loginfo("Response = {0}".format(resp))

    #rospy.loginfo("Base position = [{0},{1},{2}".format(resp.solution.joint_state.position[0],resp.solution.joint_state.position[1],resp.solution.joint_state.position[2]))
    position = resp.solution.joint_state.position
    print(position)
    #rospy.loginfo("Arm position = [{0},{1},{2},{3},{4},{5}]".format(position[0], position[1], position[2], position[3], position[4], position[5]))
