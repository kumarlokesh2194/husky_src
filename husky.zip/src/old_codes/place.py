#! /usr/bin/env python

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from geometry_msgs.msg import PoseStamped
from math import pi
from gazebo_ros_link_attacher.srv import Attach, AttachRequest, AttachResponse

def attach():
    #rospy.init_node('demo_attach_links')
    rospy.loginfo("Creating ServiceProxy to /link_attacher_node/attach")
    attach_srv = rospy.ServiceProxy('/link_attacher_node/attach',
                                    Attach)
    attach_srv.wait_for_service()
    rospy.loginfo("Created ServiceProxy to /link_attacher_node/attach")

    # Link them
    rospy.loginfo("Attaching cube1 and cube2")
    req = AttachRequest()
    req.model_name_1 = "husky1"
    req.link_name_1 = "robotiq_85_left_finger_tip_link"
    req.model_name_2 = "cube1"
    req.link_name_2 = "link"

    attach_srv.call(req)
    # From the shell:
    """
rosservice call /link_attacher_node/attach "model_name_1: 'cube1'
link_name_1: 'link'
model_name_2: 'cube2'
link_name_2: 'link'"
    """

    #rospy.loginfo("Attaching cube2 and cube3")
    #req = AttachRequest()
    #req.model_name_1 = "husky1"
    #req.link_name_1 = "robotiq_85_right_finger_tip_link"
    #req.model_name_2 = "cube1"
    #req.link_name_2 = "link"

    #attach_srv.call(req)

    #rospy.loginfo("Attaching cube3 and cube1")
    #req = AttachRequest()
    #req.model_name_1 = "cube3"
    #req.link_name_1 = "link"
    #req.model_name_2 = "cube1"
    #req.link_name_2 = "link"

    #attach_srv.call(req)

def detach():
    #rospy.init_node('demo_detach_links')
    rospy.loginfo("Creating ServiceProxy to /link_attacher_node/detach")
    attach_srv = rospy.ServiceProxy('/link_attacher_node/detach',
                                    Attach)
    attach_srv.wait_for_service()
    rospy.loginfo("Created ServiceProxy to /link_attacher_node/detach")

    # Link them
    #rospy.loginfo("Detaching cube1 and cube2")
    req = AttachRequest()
    req.model_name_1 = "husky1"
    req.link_name_1 = "robotiq_85_left_finger_tip_link"
    req.model_name_2 = "cube1"
    req.link_name_2 = "link"

    attach_srv.call(req)
    # From the shell:
    """
rosservice call /link_attacher_node/detach "model_name_1: 'cube1'
link_name_1: 'link'
model_name_2: 'cube2'
link_name_2: 'link'"
    """

    #rospy.loginfo("Attaching cube2 and cube3")
    #req = AttachRequest()
    #req.model_name_1 = "/"
    #req.link_name_1 = "robotiq_85_right_finger_tip_link"
    #req.model_name_2 = "cube1"
    #req.link_name_2 = "link"

    attach_srv.call(req)

    #rospy.loginfo("Attaching cube3 and cube1")
    #req = AttachRequest()
    #req.model_name_1 = "cube3"
    #req.link_name_1 = "link"
    #req.model_name_2 = "cube1"
    #req.link_name_2 = "link"

    #attach_srv.call(req)



def move():
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('move_group_python', anonymous=True)

    robot1 = moveit_commander.RobotCommander(robot_description = "husky1/robot_description")
    scene1 = moveit_commander.PlanningSceneInterface("husky1")
    group1 = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = "arm")
    group2 = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = "gripper")


    #pose_target = geometry_msgs.msg.Pose()
    #pose_target.orientation.w = 0.0
    #pose_target.position.x = 0.6
    #pose_target.position.y = 0.11
    #pose_target.position.z = 0.45
    #group.set_pose_target(pose_target)

    #rospy.sleep(5)

    #joint_goal = group.get_current_joint_values()
    #print(joint_goal)
    #joint_goal[0] = 0
    #joint_goal[1] = -pi/3
    #joint_goal[2] = 0
    #joint_goal[3] = -pi/2
    #joint_goal[4] = 0
    #joint_goal[5] = pi/3

    #joint_gripper = [0.027540172282155825]
    #group1.go(joint_gripper, wait=True)
    #group1.stop()

    #joint_goal = [-2.0560618406210707, 2.435540972443015, -1.4330711218144747, -0.948226047786629, 0.45946918697465583, -0.04785736553861207]
    #group1.go(joint_goal, wait=True)
    #print joint_goal[0]
    #group1.stop()

    #joint_goal = [3.0885514720972385, 0.5540799814108751, 1.1129839152887162, -1.6430091063702625, 1.5974490343295042, 0.0014113819824096414]
    #group1.go(joint_goal, wait=True)
    #print joint_goal[0]
    #group1.stop()
    detach()

    joint_gripper = [8.01815494977376e-06]
    group2.go(joint_gripper, wait=True)
    group2.stop()

    #attach()

    #joint_goal =[0.22519663290738473, -0.04882965509406908, 1.5260172056696641, -1.4844620037240024, -1.7930170980192668, -0.0017833709822511834]
    #group1.go(joint_goal, wait=True)
    #print joint_goal[0]
    #group1.stop()



    #detach()

    #rospy.sleep(1)

    #p = PoseStamped()
    #p.header.frame_id = robot.get_planning_frame()
    # p.header.frame_id = "base_link"
    #p.pose.position.x = 1.0717
    #p.pose.position.y = -0.0171
    #p.pose.position.z = 0.6
    #p.pose.orientation.w = 1.0
    #scene.add_box("table", p, (1, 1, 0.01))

    #plan1 = group.plan()

    #rospy.sleep(5)
    #group.go(wait = True)

    moveit_commander.roscpp_shutdown()

if __name__ == '__main__':
    move()

