import numpy as np
import random

import numpy as np
import scipy.special
from math import pi
from numpy import linalg as LA


def levy(n = None,m = None,beta = None):
    # This function implements Levy's flight.

    # For more information see
    #'Multiobjective cuckoo search for design optimization Xin-She Yang, Suash Deb'.
    
    # Input parameters
    # n     -> Number of steps
    # m     -> Number of Dimensions
    # beta  -> Power law index  # Note: 1 < beta < 2

    # Output
    # z     -> 'n' levy steps in 'm' dimension

    num = scipy.special.gamma(1 + beta) * np.sin(pi * beta / 2)

    den = scipy.special.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2)

    sigma_u = (num / den) ** (1 / beta)

    u = np.random.normal(0,sigma_u ** 2,[n,m])
    v = np.random.normal(0,1,[n,m])
    z = u / (np.abs(v) ** (1 / beta))
    return z[0]


def Levy_Random_Walk(prev_point = None,step_size = None,x_min = None,x_max = None, y_min = None, y_max = None, z_min = None, z_max = None):
    point = np.array([0,0,0],dtype="float")
    angle = np.array([0,0,0,0,0,0],dtype="float")
    a = 1
    b = step_size
    flag = 0
    while flag == 0:

        levy_step = a * levy(1,1,1.9) + b
        x_v = random.uniform(0,1)
        y_v = random.uniform(0,1)
        z_v = random.uniform(0,1)
        V = LA.norm([x_v,y_v,z_v])
        A = np.sign(random.uniform(-1,1))
        point[0] = prev_point[0] + A * levy_step * x_v / V
        A = np.sign(random.uniform(-1,1))
        point[1] = prev_point[1] + A * levy_step * y_v / V
        A = np.sign(random.uniform(-1,1))
        point[2] = prev_point[2] + A * levy_step * z_v / V
	#print(point[2])
        if point[0] >= x_min and point[0] <= x_max and point[1] >= y_min and point[1] <= y_max and point[2] >= z_min and point[2] <= z_max:
            flag = 1


    angle[0] = np.random.uniform(-pi,pi)
    angle[1] = np.random.uniform(-pi,pi)
    angle[2] = np.random.uniform(-pi,pi)
    angle[3] = np.random.uniform(-pi,pi)
    angle[4] = np.random.uniform(-pi,pi)
    angle[5] = np.random.uniform(-pi,pi)
    return point,angle
