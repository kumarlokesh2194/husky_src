    
def Random_Walk_Bridge(point_ref = None,angle_ref = None,point = None,angle = None): 
    point_bridge = 2 * point - point_ref
    angle_bridge = 2 * angle - angle_ref
    return point_bridge,angle_bridge
    

