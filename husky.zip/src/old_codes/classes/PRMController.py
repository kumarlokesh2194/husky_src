from collections import defaultdict
import sys
import math
from math import pi
# import matplotlib.pyplot as plt
# import matplotlib.patches as patches
# from matplotlib.patches import Rectangle
import numpy as np
from sklearn.neighbors import NearestNeighbors
import shapely.geometry
import argparse
# from state_validity import StateValidity
from Dijkstra import Graph, dijkstra, to_array
from Utils import Utils
import rospy
# import plotly.graph_objects as go
import pickle
import robot_state_validity
from numpy import save


class PRMController:
    def __init__(self, numOfRandomCoordinates, current, destination):
        self.numOfCoords = numOfRandomCoordinates
        self.coordsList = np.array([])
        self.current = np.array(current)
        self.destination = np.array(destination)
        self.graph = Graph()
        self.utils = Utils()
        self.solutionFound = False

    def runPRM(self,s_points, initialRandomSeed, saveImage=True):
        seed = initialRandomSeed
        # Keep resampling if no solution found
        while(not self.solutionFound):
            print("Trying with random seed {}".format(seed))
            np.random.seed(seed)

            # Generate n random samples called milestones
            self.genCoords(s_points)

            # Check if milestones are collision free
            self.checkIfCollisonFree()

            # Link each milestone to k nearest neighbours.
            # Retain collision free links as local paths.
            self.findNearestNeighbour()

            # Search for shortest path from start to end node - Using Dijksta's shortest path alg
            c = self.shortestPath()

            seed = np.random.randint(1, 100000)
            self.coordsList = np.array([])
            self.graph = Graph()
	    return c

    def genCoords(self, s_points, maxSizeOfMap=100000):
        self.coordsList = np.random.uniform(-3.14,3.14, size=(self.numOfCoords, 6))
    	print("coord===>",self.coordsList)
        # Adding begin and end points
        self.current = self.current.reshape(1, 6)
    	#print("current===>",self.current)
        self.destination = self.destination.reshape(1, 6)
        self.coordsList = np.concatenate(
            (self.coordsList, self.current, self.destination, s_points), axis=0)
    	#print("coords_list===>",len(self.coordsList))

    def checkIfCollisonFree(self):
        collision = 0
        self.collisionFreePoints = np.array([])
    	#rospy.init_node('collision_check', anonymous=False)
        for point in self.coordsList:
            #collision = self.checkPointCollision(point)
    	    collision = robot_state_validity.check_collision(point)
            if(not collision):
                if(self.collisionFreePoints.size == 0):
                    self.collisionFreePoints = point
                else:
                    self.collisionFreePoints = np.vstack(
                        [self.collisionFreePoints, point])
	# save('data.npy', self.collisionFreePoints)


    def findNearestNeighbour(self, k=11):
        X = self.collisionFreePoints
    	print("X=====X",len(X))
        knn = NearestNeighbors(n_neighbors=k, metric='minkowski', p=1, metric_params=None, n_jobs=None,radius = 3)
        knn.fit(X)
        distances, indices = knn.kneighbors(X)

        self.collisionFreePaths = np.empty((1, 6), float)
    	n = 0
        for i, p in enumerate(X):
            # Ignoring nearest neighbour - nearest neighbour is the point itself
            for j, neighbour in enumerate(X[indices[i][1:]]):
                n = n+1
                start_line = p
                end_line = neighbour
                print("start_line===>",start_line)
                print("end_line===>",end_line)
                #if(not self.checkPointCollision(end_line)):
                if(not self.checkLineCollision(start_line, end_line)):
                    self.collisionFreePaths = np.concatenate(
                    (self.collisionFreePaths, p.reshape(1, 6), neighbour.reshape(1, 6)), axis=0)

                    a = str(self.findNodeIndex(p))
                    b = str(self.findNodeIndex(neighbour))
                    self.graph.add_node(a)
                    self.graph.add_edge(a, b, distances[i, j+1])
    	print("n, X===>",n,len(X))
        print("distances===>",distances,indices)


    def shortestPath(self):
        self.startNode = str(self.findNodeIndex(self.current))
        self.endNode = str(self.findNodeIndex(self.destination))
    	print(self.startNode)

        final_points = []

    	with open("manipulator.pickle", "wb") as file_:
    		pickle.dump(self.graph, file_)

        dist, prev = dijkstra(self.graph, self.startNode)

        pathToEnd = to_array(prev, self.endNode)

        if(len(pathToEnd) > 1):
	    print("<=== solution found ===>")
            self.solutionFound = True
        else:
	    print("<=== no solution found ===>")
            return

        #shorest path
        pointsToDisplay = [(self.findPointsFromNode(path))
                           for path in pathToEnd]

        pointsToEnd = [np.array(self.findPointsFromNode(path))
                       for path in pathToEnd]
        print("\n\n****Output****\n\n")
        print("The quickest path from {} to {} is: \n\n {}".format(
            self.collisionFreePoints[int(self.startNode)],
            self.collisionFreePoints[int(self.endNode)],pointsToEnd))
        for i in pointsToEnd:
            final_points.append(i)
        return(final_points)

    def checkLineCollision(self, start_line, end_line):
    	collision = 0
    	X1 = start_line[0]
    	X2 = start_line[1]
    	X3 = start_line[2]
    	X4 = start_line[3]
    	X5 = start_line[4]
    	X6 = start_line[5]

    	x1 = end_line[0]
    	x2 = end_line[1]
    	x3 = end_line[2]
    	x4 = end_line[3]
    	x5 = end_line[4]
    	x6 = end_line[5]

    	r1 = (X1+x1)/2
    	r2 = (X2+x2)/2
    	r3 = (X3+x3)/2
    	r4 = (X4+x4)/2
    	r5 = (X5+x5)/2
    	r6 = (X6+x6)/2

    	R1 = (X1+r1)/2
    	R2 = (X2+r2)/2
    	R3 = (X3+r3)/2
    	R4 = (X4+r4)/2
    	R5 = (X5+r5)/2
    	R6 = (X6+r6)/2

    	c1 = (R1+X1)/2
    	c2 = (R2+X2)/2
    	c3 = (R3+X3)/2
    	c4 = (R4+X4)/2
    	c5 = (R5+X5)/2
    	c6 = (R6+X6)/2

    	d1 = (R1+r1)/2
    	d2 = (R2+r2)/2
    	d3 = (R3+r3)/2
    	d4 = (R4+r4)/2
    	d5 = (R5+r5)/2
    	d6 = (R6+r6)/2

    	Rr1 = (x1+r1)/2
    	Rr2 = (x2+r2)/2
    	Rr3 = (x3+r3)/2
    	Rr4 = (x4+r4)/2
    	Rr5 = (x5+r5)/2
    	Rr6 = (x6+r6)/2

    	cr1 = (Rr1+x1)/2
    	cr2 = (Rr2+x2)/2
    	cr3 = (Rr3+x3)/2
    	cr4 = (Rr4+x4)/2
    	cr5 = (Rr5+x5)/2
    	cr6 = (Rr6+x6)/2

    	dr1 = (r1+Rr1)/2
    	dr2 = (r2+Rr2)/2
    	dr3 = (r3+Rr3)/2
    	dr4 = (r4+Rr4)/2
    	dr5 = (r5+Rr5)/2
    	dr6 = (r6+Rr6)/2




    	point1 = np.array([r1,r2,r3,r4,r5,r6])
    	point2 = np.array([R1,R2,R3,R4,R5,R6])
    	point3 = np.array([c1,c2,c3,c4,c5,c6])
    	point4 = np.array([d1,d2,d3,d4,d5,d6])
    	point5 = np.array([Rr1,Rr2,Rr3,Rr4,Rr5,Rr6])
    	point6 = np.array([cr1,cr2,cr3,cr4,cr5,cr6])
    	point7 = np.array([dr1,dr2,dr3,dr4,dr5,dr6])

    	#collision_check = StateValidity()
        if(robot_state_validity.check_collision(point1)):
            return 1
        elif(robot_state_validity.check_collision(point2)):
    	    return 1
    	elif(robot_state_validity.check_collision(point3)):
    	    return 1
    	elif(robot_state_validity.check_collision(point4)):
    	    return 1
    	elif(robot_state_validity.check_collision(point5)):
            return 1
        elif(robot_state_validity.check_collision(point6)):
    	    return 1
    	elif(robot_state_validity.check_collision(point7)):
    	    return 1
        return 0

    def findNodeIndex(self, p):
        return np.where((self.collisionFreePoints == p).all(axis=1))[0][0]

    def findPointsFromNode(self, n):
        return self.collisionFreePoints[int(n)]

    def checkCollision(self, obs, point):
        p_x = point[0]
        p_y = point[1]
        if(obs.bottomLeft[0] <= p_x <= obs.bottomRight[0] and obs.bottomLeft[1] <= p_y <= obs.topLeft[1]):
            return True
        else:
            return False

    def checkPointCollision(self, point):
        collision_check = StateValidity()
	collision = collision_check.start_collision_checker(point)

        if(collision):
            return 1
        return 0

if __name__=="__main__":
    numOfRandomCoordinates = 1000
    current = np.array([-0.3162940540455672, -0.9215418778233673, 0.44509270696654735, -1.0242492789177549, -2.1432803683772006, -2.406297174683676])
    destination = np.array([-2.310844853135981, -1.2286794165658517, 1.3487265881061248, 1.4911039128946486, 0.9659852296630467, -1.6550880799598504])
    c = PRMController(numOfRandomCoordinates,current,destination)
    c.shortestPath()
