#!/usr/bin/env python
import sys
from classes import PRMController, Obstacle, Utils
import numpy as np
import Levy_Random_Walk
import Random_Walk_Bridge
#from state_validity_ import StateValidity
import random
from math import pi
import rospy
from moveit_msgs.srv import GetStateValidityRequest, GetStateValidity
from moveit_msgs.msg import RobotState
from sensor_msgs.msg import JointState
import arm_control
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
import pose
from trajectory_msgs.msg import JointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from marker import TrajectoryInteractiveMarkers
import pose_
import robot_state_validity
import time


def main(current,destination,s_points):
    prm = PRMController(300, current, destination)
    # Initial random seed to try
    initialRandomSeed = 0
    s_points.append(current)
    s_points.append(destination)
    print("\n\nadding LFBS nodes to PRM road map\n\n")
    c = prm.runPRM(s_points,initialRandomSeed)
    # print("s_points==>",s_points)
    # #pose.move_arm(c)
    # r =  c[::-1]
    # print("ccccccc",c)
    # print("=======>",r)
    return c,s_points


def levy():
    t1 = time.time()
    rospy.init_node('collision_check', anonymous=False)
    ssss = rospy.get_time()
    min_ = -3.14
    max_ =  3.14
    collision_check = 0
    n_obs = 1
    step_size = .2
    n_samples = 50
    k = 1
    sampled_points = []
    global sh_lift,sh_pan,elbow,w_1,w_2,w_3
    while k <= n_samples:
        #-----Random Test Object Position-----
        sh_pan = random.uniform(-3.14,3.14)
        sh_lift = random.uniform(-3.14,3.14)
        elbow = random.uniform(-3.14,3.14)
        w_1 = random.uniform(-3.14,3.14)
        w_2 = random.uniform(-3.14,3.14)
        w_3 = random.uniform(-3.14,3.14)
        angle_ref = np.array([sh_pan,sh_lift,elbow,w_1,w_2,w_3])
        collision_1 = 0
        collision_1 = robot_state_validity.check_collision(angle_ref)
        if collision_1:
            point = np.array([sh_pan, sh_lift, elbow, w_1, w_2, w_3])
            while True:
                prev_point = point
                angle = Levy_Random_Walk.Levy_Random_Walk(prev_point,step_size,min_,max_)
                collision_2 = 0
                collision_2 = robot_state_validity.check_collision(angle)
                if collision_2 == 0:
                    angle_bridge = Random_Walk_Bridge.Random_Walk_Bridge(angle_ref,angle)
                    logic_bridge = 0
                    logic_bridge = robot_state_validity.check_collision(angle_bridge)
                    if logic_bridge != 0:
                        sampled_points.append(angle)
                        k = k + 1
                        print("k========>",k)
                        break
                    else:
                        break
    s_points = sampled_points
    rospy.sleep(0.1)
    t2 = time.time()
    eeee = rospy.get_time()
    return s_points,(t2-t1)



def execute(current,destination):
    s_points,time_taken = levy()
    print("time from levy:{}".format(time_taken))
    points,s = main(current,destination,s_points)
    n = 0
    node = []
    for i in points:
        for j in s_points:
            if i[0]==j[0] and i[1]==j[1] and i[2]==j[2] and i[3]==j[3] and i[4]==j[4] and i[5]==j[5]:
                n = n+1
                node.append(i)

    print("\n\n{} nodes from narrow passage\n\n".format(n-2))
    print("nodes",node)
    return time_taken,points


if __name__ == '__main__':
    t1 = time.time()
    destination = [-0.6717539423982046, 0.5728036604821495, -0.32726722201643393, -0.2397305049493229, 0.9997657522741431, -0.0032926761664615655]
    current = [-1.783534710308342, -2.8805703353129477, 2.445513138456365, -2.706119339013748, 1.77408822885347, -3.1365923804221993]
    trajectory_interactive_markers = TrajectoryInteractiveMarkers()
    time_taken,points = execute(current,destination)
    t2 = time.time()
    print("time_taken:{}".format(t2-t1))
    print("time for levy:{}".format(time_taken))
    pub_arm_joint = rospy.Publisher("/arm_controller/command", JointTrajectory, queue_size=1)
    for i in points:
        msg = move_arm(i)
        pub_arm_joint.publish(msg)
        rospy.sleep(5)

# x = 2.744898 y = 7.210495 z = 0.256588 mesh x = 2.607082 y = 7.184448 z = 0.882088 roll-1.570624
