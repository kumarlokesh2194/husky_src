#!  /usr/bin/env python

import rospy
from trajectory_msgs.msg import JointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from std_msgs.msg import Header
import main
from numpy import array


def move_arm(point):

	#rospy.init_node("move_arm")
	#rate = rospy.Rate(10)

	#pub_arm_joint = rospy.Publisher("/arm_controller/command", JointTrajectory, queue_size=1)
	move_arm_joint = JointTrajectory()
	move_arm_position = JointTrajectoryPoint()
	move_arm_joint.joint_names = ["shoulder_pan_joint","shoulder_lift_joint","elbow_joint","wrist_1_joint","wrist_2_joint","wrist_3_joint"]
	move_arm_position.positions = point
	move_arm_position.velocities = [.1,.1,.1,.1,.1,.1]
	move_arm_position.accelerations = [.1,.1,.1,.1,.1,.1]
	move_arm_position.effort = [0]
	move_arm_position.time_from_start.secs = 4
	move_arm_position.time_from_start.nsecs = 4

	move_arm_joint.points = [move_arm_position]
	move_arm_joint.header.frame_id = "wrist_3_link"
	return move_arm_joint


if __name__ == "__main__":
	rospy.init_node("move_arm")
	#rate = rospy.Rate(10)
	pub_arm_joint = rospy.Publisher("/arm_controller/command", JointTrajectory, queue_size=1)

 	points =     array([-0.10112356, -0.17856493,  1.5549665 , -0.14032276,  2.41951344,
       -3.05945961])


	n = 0
	l = len(points)
	for i in points:
		msg = move_arm(i)
		print("ccc")

			#rospy.Timer(rospy.Duration(1.0/10.0), msg)
  		pub_arm_joint.publish(msg)
			#if n == l:
		    	#	rospy.isshutdown()
		rospy.sleep(5)
