#!/usr/bin/env python

import rospy
from moveit_msgs.srv import GetStateValidity, GetStateValidityRequest
from moveit_msgs.msg import RobotState
from geometry_msgs.msg import Transform
from sensor_msgs.msg import JointState
import numpy as np
from numpy import array

def call_service():
    sv_srv = rospy.ServiceProxy("husky1/check_state_validity",GetStateValidity)
    ##sv_srv.wait_for_service()
    #rospy.loginfo("service is available")

    return sv_srv

def set_robot_state(point):
    rs = RobotState()
    tf = JointState()

    tf.name = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']
    tf.position = point
    rs.joint_state = tf
    return rs

def check_collision(pose,group_name='arm',constraints=None):
    gsvr = GetStateValidityRequest()
    rs = set_robot_state(pose)
    sv_srv = call_service()
    gsvr.robot_state = rs
    gsvr.group_name = group_name
    if constraints != None:
        gsvr.constraints = constraints
    result = sv_srv.call(gsvr)
    flag = 0
    if result.valid:
        rospy.loginfo("robot not in collision")
        flag = 0
        #rospy.loginfo("robot not in collision")
    else:
        rospy.logwarn("robot in collision")
        flag = 1
    return flag



if __name__ == "__main__":
    rospy.init_node('collision_checker_node', anonymous=False)
    pose = array([0,0,0,0,0,0])

    check_collision(pose)
    rospy.spin()


        pose_target = PoseStamped()
        pose_target.header.frame_id = "base_link"
        pose_target.pose.orientation.w = 1
        pose_target.pose.orientation.x = 0
        pose_target.pose.orientation.y = 0
        pose_target.pose.orientation.z = 0
        pose_target.pose.position.x = 0.6344
        pose_target.pose.position.y = -0.5987
        pose_target.pose.position.z = 0.6726
