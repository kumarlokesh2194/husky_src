from collections import defaultdict
import sys
import math
from math import pi
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import Rectangle
import numpy as np
from sklearn.neighbors import NearestNeighbors
import shapely.geometry
import argparse
from state_validity import StateValidity
from Dijkstra import Graph, dijkstra, to_array
from Utils import Utils
import rospy
import plotly.graph_objects as go
import pickle


class PRMController:
    def __init__(self, numOfRandomCoordinates, current, destination):
        self.numOfCoords = numOfRandomCoordinates
        self.coordsList = np.array([])
        self.current = np.array(current)
        self.destination = np.array(destination)
        self.graph = Graph()
        self.utils = Utils()
        self.solutionFound = False

    def runPRM(self,s_points, initialRandomSeed, saveImage=True):
        seed = initialRandomSeed
        # Keep resampling if no solution found
        while(not self.solutionFound):
            print("Trying with random seed {}".format(seed))
            np.random.seed(seed)

            # Generate n random samples called milestones
            self.genCoords(s_points)

            # Check if milestones are collision free
            self.checkIfCollisonFree()

            # Link each milestone to k nearest neighbours.
            # Retain collision free links as local paths.
            self.findNearestNeighbour()

            # Search for shortest path from start to end node - Using Dijksta's shortest path alg
            c = self.shortestPath()

            seed = np.random.randint(1, 100000)
            self.coordsList = np.array([])
            self.graph = Graph()
	    return c

        #if(saveImage):
        #    plt.savefig("{}_samples.png".format(self.numOfCoords))
        #plt.show()

    def genCoords(self, s_points, maxSizeOfMap=100):
        self.coordsList = np.random.uniform(-pi,pi, size=(self.numOfCoords, 6))
	#print("coord===>",self.coordsList)
        # Adding begin and end points
        self.current = self.current.reshape(1, 6)
	#print("current===>",self.current)
        self.destination = self.destination.reshape(1, 6)
        self.coordsList = np.concatenate(
            (self.coordsList, self.current, self.destination, s_points), axis=0)
	#print("coords_list===>",len(self.coordsList))

    def checkIfCollisonFree(self):
        collision = 0
        self.collisionFreePoints = np.array([])
	#rospy.init_node('collision_check', anonymous=False)
        for point in self.coordsList:
            #collision = self.checkPointCollision(point)
            collision_check = StateValidity()
	    collision = collision_check.start_collision_checker(point)
            if(not collision):
                if(self.collisionFreePoints.size == 0):
                    self.collisionFreePoints = point
                else:
                    self.collisionFreePoints = np.vstack(
                        [self.collisionFreePoints, point])
        self.plotPoints(self.collisionFreePoints)  
	#file = open("file1.txt", "w+") 
	#content = str(self.collisionFreePoints)
	#file.write(content) 
	#file.close()
        #print("collision free===>",(self.collisionFreePoints.size),(self.coordsList.size))
        #print("collision===>",self.collisionFreePoints[1],self.collisionFreePoints[2])

    def findNearestNeighbour(self, k=10):
        X = self.collisionFreePoints
        knn = NearestNeighbors(n_neighbors=k) #,radius=1.0, algorithm='auto', leaf_size=30, metric='minkowski', p=2, metric_params=None, n_jobs=None)
        knn.fit(X)
        distances, indices = knn.kneighbors(X)
        #print("distances===>",distances[1],indices[1])
        self.collisionFreePaths = np.empty((1, 6), float)

        for i, p in enumerate(X):
            # Ignoring nearest neighbour - nearest neighbour is the point itself
            for j, neighbour in enumerate(X[indices[i][1:]]):
                start_line = p
                end_line = neighbour
		#print("start_line===>",start_line)
  		#print("end_line===>",end_line)
                if(not self.checkPointCollision(start_line) and not self.checkPointCollision(end_line)):
                    if(not self.checkLineCollision(start_line, end_line)):
                        self.collisionFreePaths = np.concatenate(
                            (self.collisionFreePaths, p.reshape(1, 6), neighbour.reshape(1, 6)), axis=0)

                        a = str(self.findNodeIndex(p))
                        b = str(self.findNodeIndex(neighbour))
                        self.graph.add_node(a)
                        self.graph.add_edge(a, b, distances[i, j+1])
	    #print("a,b===>",a,b)


    def shortestPath(self):
        self.startNode = str(self.findNodeIndex(self.current))
        self.endNode = str(self.findNodeIndex(self.destination))
	print(self.startNode)

        final_points = []
	#with open("filename.pickle", "wb") as file_:
    	#	pickle.dump(self.graph, file_, -1)
	#print(self.graph)
	#with open('filename.pickle', 'rb') as fp:
        #    graph = pickle.load(fp)
        dist, prev = dijkstra(self.graph, self.startNode)

        pathToEnd = to_array(prev, self.endNode)

        if(len(pathToEnd) > 1):
	    print("<=== solution found ===>")
            self.solutionFound = True
        else:
	    print("<=== no solution found ===>")
            return

        # Plotting shorest path
        pointsToDisplay = [(self.findPointsFromNode(path))
                           for path in pathToEnd]

       #x = [item[0] for item in pointsToDisplay]
       # y = [item[1] for item in pointsToDisplay]
       # z = [item[2] for item in pointsToDisplay]
       # fig = go.Figure(data=[go.Scatter3d(x=x, y=y, z=z,mode='markers')])
       # fig.show()

        pointsToEnd = [np.array(self.findPointsFromNode(path))
                       for path in pathToEnd]
        print("\n\n****Output****\n\n")

        #print("The quickest path from {} to {} is: \n {} \n with a distance of {}".format(
         #   self.collisionFreePoints[int(self.startNode)],
         #   self.collisionFreePoints[int(self.endNode)],
         #   " \n ".join(pointsToEnd),
         #   str(dist[self.endNode])
        print("The quickest path from {} to {} is: \n\n {}".format(
            self.collisionFreePoints[int(self.startNode)],
            self.collisionFreePoints[int(self.endNode)],pointsToEnd))

	#final_points.append(self.collisionFreePoints[int(self.startNode)])
        #final_points.append(self.collisionFreePoints[int(self.endNode)])
        for i in pointsToEnd:
            final_points.append(i)
        return(final_points)

    def checkLineCollision(self, start_line, end_line):
        collision = 0
	X1 = start_line[0]
	X2 = start_line[1]
	X3 = start_line[2]
	X4 = start_line[3]
	X5 = start_line[4]
	X6 = start_line[5]

	x1 = end_line[0]
	x2 = end_line[1]
	x3 = end_line[2]
	x4 = end_line[3]
	x5 = end_line[4]
	x6 = end_line[5]

	r1 = np.random.uniform(X1,x1)
	r2 = np.random.uniform(X2,x2)
	r3 = np.random.uniform(X3,x3)
	r4 = np.random.uniform(X4,x4)
	r5 = np.random.uniform(X5,x5)
	r6 = np.random.uniform(X6,x6)

	R1 = np.random.uniform(X1,x1)
	R2 = np.random.uniform(X2,x2)
	R3 = np.random.uniform(X3,x3)
	R4 = np.random.uniform(X4,x4)
	R5 = np.random.uniform(X5,x5)
	R6 = np.random.uniform(X6,x6)

	c1 = (X1+r1)/2
	c2 = (X2+r2)/2
	c3 = (X3+r3)/2
	c4 = (X4+r4)/2
	c5 = (X5+r5)/2
	c6 = (X6+r6)/2

	C1 = (x1+r1)/2
	C2 = (x2+r2)/2
	C3 = (x3+r3)/2
	C4 = (x4+r4)/2
	C5 = (x5+r5)/2
	C6 = (x6+r6)/2


	rr1 = (r1+R1)/2
	rr2 = (r2+R2)/2
	rr3 = (r3+R3)/2
	rr4 = (r4+R4)/2
	rr5 = (r5+R5)/2
	rr6 = (r6+R6)/2

	point1 = np.array([c1,c2,c3,c4,c5,c6])
	point2 = np.array([C1,C2,C3,C4,C5,C6])
	point3 = np.array([rr1,rr2,rr3,rr4,rr5,rr6])
	collision_check = StateValidity()
	collision = collision_check.start_collision_checker(point1)       
	collision1 = collision_check.start_collision_checker(point2) 
	collision2 = collision_check.start_collision_checker(point3)  
        if(collision==1 or collision1==1 or collision2==1):
            return 1
        return 0

    def findNodeIndex(self, p):
	#file = open("file1.txt", "r")
	#content = file.read() 
	#file.close()
        #self.collisionFreePoints = np.array([content])
        return np.where((self.collisionFreePoints == p).all(axis=1))[0][0]

    def findPointsFromNode(self, n):
	file = open("file1.txt", "r")
	content = file.read() 
	file.close()
        self.collisionFreePoints = np.array([content])
        return self.collisionFreePoints[int(n)]

    def plotPoints(self, points):
        #x = [item[0] for item in points]
        #y = [item[1] for item in points]
        #z = [item[3] for item in points]
        #fig = go.Figure(data=[go.Scatter3d(x=x, y=y, z=z,mode='markers')])
        #fig.show()
        return


    def checkCollision(self, obs, point):
        p_x = point[0]
        p_y = point[1]
        if(obs.bottomLeft[0] <= p_x <= obs.bottomRight[0] and obs.bottomLeft[1] <= p_y <= obs.topLeft[1]):
            return True
        else:
            return False

    def checkPointCollision(self, point):
        collision_check = StateValidity()
	collision = collision_check.start_collision_checker(point)
            
        if(collision):
            return 1
        return 0

if __name__=="__main__":
    numOfRandomCoordinates = 1000
    current = np.array([-0.3162940540455672, -0.9215418778233673, 0.44509270696654735, -1.0242492789177549, -2.1432803683772006, -2.406297174683676])
    destination = np.array([-2.310844853135981, -1.2286794165658517, 1.3487265881061248, 1.4911039128946486, 0.9659852296630467, -1.6550880799598504])
    c = PRMController(numOfRandomCoordinates,current,destination)
    c.shortestPath()
    
