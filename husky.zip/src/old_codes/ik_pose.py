#! /usr/bin/env python

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from geometry_msgs.msg import PoseStamped
from math import pi
from gazebo_ros_link_attacher.srv import Attach, AttachRequest, AttachResponse
from trajectory_msgs.msg import JointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from std_msgs.msg import Header
from numpy import array
from std_srvs.srv import Empty
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from sensor_msgs.msg import PointCloud2
import time
from numpy import array

def callback(msg):
    global flag
    global time_taken
    time1 = time.time()
    # while time_taken < 1:
    pub.publish(msg)
    time2 = time.time()
    time_taken = time2 - time1
#    print time_taken
    # sv_srv = rospy.ServiceProxy("/clear_octomap",Empty)
    # sv_srv.call()

    rospy.sleep(3)
    flag = 0

def callback_pose(msg):
    global pose_target
    if msg.child_frame_id == "modified_warehouse_clone_0_clone_0_clone_clone_clone_clone_clone_clone_0":
        pose_target = geometry_msgs.msg.Pose()
        pose_target.orientation.w = msg.transform.rotation.w
        pose_target.orientation.x = msg.transform.rotation.x
        pose_target.orientation.y = msg.transform.rotation.y
        pose_target.orientation.z = msg.transform.rotation.z
        pose_target.position.x = msg.transform.translation.x
        pose_target.position.y = msg.transform.translation.y
        pose_target.position.z = msg.transform.translation.z






def move():
    global pose_target
    pose_target = geometry_msgs.msg.Pose()
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('move_group_python', anonymous=True)
    rospy.Subscriber("pick_pose",geometry_msgs.msg.TransformStamped,callback_pose)

    robot1 = moveit_commander.RobotCommander(robot_description = "husky1/robot_description")
    scene1 = moveit_commander.PlanningSceneInterface("husky1")
    group = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = "arm")
    group2 = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = "gripper")

    # for quat in point:
    pose_target = PoseStamped()
    pose_target.header.frame_id = "base_link"
    pose_target.pose.orientation.w = 1
    pose_target.pose.orientation.x = 0
    pose_target.pose.orientation.y = 0
    pose_target.pose.orientation.z = 0
    pose_target.pose.position.x = 0.5515
    pose_target.pose.position.y = -0.09634
    pose_target.pose.position.z = 0.672
    print(pose_target)
    group.set_pose_target(pose_target)
    # sv_srv = rospy.ServiceProxy("/clear_octomap",Empty)
    # sv_srv.call()
    # group.plan()
    # group.plan()
    # group.plan()
    # group.plan()
    # group.plan()
    # group.plan()
    # group.plan()
    # group.plan()
    # group.plan()
    # group.plan()

    # joint = group.get_current_joint_values()
    # print(joint)

    # joint_goal = group.get_current_joint_values()
    # print(joint_goal)
    #joint_goal[0] = 0
    #joint_goal[1] = -pi/3
    #joint_goal[2] = 0
    #joint_goal[3] = -pi/2
    #joint_goal[4] = 0
    #joint_goal[5] = pi/3
	#
    # joint_gripper = [0.027540172282155825]
    # group1.go(joint_gripper, wait=True)
    # group1.stop()
	#
    # joint_goal = [2.5594785236635915, -1.9044956668180246, 1.541772687413668, 0.3699905244102549, 1.001448606750577, -0.008009692750515862]
    # group.go(joint_goal, wait=True)
    # #print joint_goal[0]
    # group.stop()
	#
    # joint_goal = [2.79452589571766, -1.4582218093131145, 1.1573683469188523, 0.30733322827510223, 1.2364900879959655, -0.006217819672323821]
    # group.go(joint_goal, wait=True)
    # print joint_goal[0]
    # group.stop()
	#
    # joint_gripper = [0.45]
    # group1.go(joint_gripper, wait=True)
    # group1.stop()
	#
    # attach()

    #joint_goal = [2.540440584695485, -1.9981821130828583, 1.8972598416743387, 0.10042318783493442, 0.9684531626420737, -0.0006339319476427656]
    #group.go(joint_goal, wait=True)
    #print joint_goal[0]
    #group.stop()

    #joint_gripper = [0.027540172282155825]
    #group1.go(joint_gripper, wait=True)
    #group1.stop()

    #detach()

    #rospy.sleep(1)

    p = PoseStamped()
    p.header.frame_id = robot.get_planning_frame()
    p.header.frame_id = "base_link"
    p.pose.position.x = 0.16
    p.pose.position.y = 0.08
    p.pose.position.z = 0.64
    p.pose.orientation.w = 1.0
    scene.add_box("table", p, (0.1, 0.1, 0.01))

    #plan1 = group.plan()

    #rospy.sleep(5)
    #group.go(wait = True)

    moveit_commander.roscpp_shutdown()

if __name__ == '__main__':
    move()
    time_taken = 0
    flag = 1
    r = rospy.Rate(1)
    sub = rospy.Subscriber("/camera/depth/points", PointCloud2, callback)
    pub = rospy.Publisher("/lokesh/depth/points", PointCloud2, queue_size = 1)
    while not rospy.is_shutdown():
        r.sleep()
    #rate = rospy.Rate(10)
    # pub_arm_joint1 = rospy.Publisher("/robot1/arm_controller/command", JointTrajectory, queue_size=1)
    # pub_arm_joint2 = rospy.Publisher("/robot2/arm_controller/command", JointTrajectory, queue_size=1)
    # pub_gripper_joint1 = rospy.Publisher("/robot1/gripper_controller/command", JointTrajectory, queue_size=1)
    # pub_gripper_joint2 = rospy.Publisher("/robot2/gripper_controller/command", JointTrajectory, queue_size=1)
    # # pub_arm_joint3 = rospy.Publisher("/robot3/arm_controller/command", JointTrajectory, queue_size=1)
	#
    # arm_joints =   [[0,0,0,0,0,0],[-0.12673957870912655, -0.41121026152494566, 2.154675607101795, -1.7247966840942774, 1.3976371605053166, 0.0037959267834042237]]
    # gripper_joints = [[0],[0.6783151216755539]]
	#
    # n = 0
    # # l = len(points)
    # for i in arm_joints:
    #     print i
    #     msg_arm = move_arm(i)
    #     print("ccc")
    #     pub_arm_joint1.publish(msg_arm)
    #     pub_arm_joint2.publish(msg_arm)
    #     #pub_gripper_joint1.publish(msg_gripper)
    #     #pub_gripper_joint2.publish(msg_gripper)
    #     # pub_arm_joint3.publish(msg)
    #     #if n == l:
    #     #	rospy.isshutdown()
    #     rospy.sleep(2)
	#
    # for j in arm_joints:
    #     print j
    #     msg_gripper = move_gripper(j)
    #     print("ccc")
    #     pub_gripper_joint1.publish(msg_gripper)
    #     pub_gripper_joint2.publish(msg_gripper)
    #     # pub_arm_joint3.publish(msg)
    #     #if n == l:
    #     #	rospy.isshutdown()
    #     rospy.sleep(2)
