import numpy as np
import random
import numpy as np
import scipy.special
from math import pi
from numpy import linalg as LA


def levy(n = None,m = None,beta = None):
    # This function implements Levy's flight.

    # For more information see
    #'Multiobjective cuckoo search for design optimization Xin-She Yang, Suash Deb'.

    # Input parameters
    # n     -> Number of steps
    # m     -> Number of Dimensions
    # beta  -> Power law index  # Note: 1 < beta < 2

    # Output
    # z     -> 'n' levy steps in 'm' dimension

    num = scipy.special.gamma(1 + beta) * np.sin(pi * beta / 2)

    den = scipy.special.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2)

    sigma_u = (num / den) ** (1 / beta)

    u = np.random.normal(0,sigma_u ** 2,[n,m])
    v = np.random.normal(0,1,[n,m])
    z = u / (np.abs(v) ** (1 / beta))
    return z[0]


def Levy_Random_Walk(prev_point = None,step_size = None, min_ = None, max_ = None):
    point = np.array([0,0,0],dtype="float")
    angle = np.array([0,0,0,0,0,0],dtype="float")
    angle1 = np.array([0,0,0,0,0,0],dtype="float")
    a = 1
    b = step_size
    flag = 0
    i = a * levy(1,1,1.1) + b

    while flag == 0:
        angle1[0] = np.random.rand()
    	angle1[1] = np.random.rand()
        angle1[2] = np.random.rand()
    	angle1[3] = np.random.rand()
    	angle1[4] = np.random.rand()
    	angle1[5] = np.random.rand()
        V = LA.norm([angle1[0],angle[1],angle[2],angle[3],angle[4],angle[5]])
        A = np.sign(np.random.randn())
        angle[0] = prev_point[0] + A * i[0] * angle1[0] / V
        A = np.sign(np.random.randn())
        angle[1] = prev_point[1] + A * i[0] * angle1[1] / V
        A = np.sign(np.random.randn())
        angle[2] = prev_point[2] + A * i[0] * angle1[2] / V
        A = np.sign(np.random.randn())
        angle[3] = prev_point[3] + A * i[0] * angle1[3] / V
        A = np.sign(np.random.randn())
        angle[4] = prev_point[4] + A * i[0] * angle1[4] / V
        A = np.sign(np.random.randn())
        angle[5] = prev_point[5] + A * i[0] * angle1[5] / V

        if (angle[0] >= min_ and angle[0] <= max_) and (angle[1] >= min_ and angle[1] <= max_) and (angle[2] >= min_ and angle[2] <= max_) and (angle[3] >= min_ and angle[3] <= max_) and (angle[4] >= min_ and angle[4] <= max_) and (angle[5] >= min_ and angle[5] <= max_):
            flag = 1

    return angle

if __name__ == '__main__':
    min_ = -pi
    max_ =  pi
    sh_pan = random.uniform(-pi,pi)
    sh_lift = random.uniform(-pi,pi)
    elbow = random.uniform(-pi,pi)
    w_1 = random.uniform(-pi,pi)
    w_2 = random.uniform(-pi,pi)
    w_3 = random.uniform(-pi,pi)
    step_size = 0.5
    point = np.array([sh_pan, sh_lift, elbow, w_1, w_2, w_3])

    angle = Levy_Random_Walk(point,step_size,min_,max_)

    print angle
