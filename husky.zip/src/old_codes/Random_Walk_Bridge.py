import numpy as np
def Random_Walk_Bridge(angle_ref,angle):
    angle_bridge = np.array([0,0,0,0,0,0],dtype="float")
    #angle_bridge = 2 * angle - angle_ref
    angle_bridge = -1 * angle_ref
    return angle_bridge
