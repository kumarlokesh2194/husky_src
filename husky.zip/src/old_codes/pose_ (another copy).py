#! /usr/bin/env python

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from geometry_msgs.msg import PoseStamped
from math import pi
from gazebo_ros_link_attacher.srv import Attach, AttachRequest, AttachResponse

def attach():
    #rospy.init_node('demo_attach_links')
    rospy.loginfo("Creating ServiceProxy to /link_attacher_node/attach")
    attach_srv = rospy.ServiceProxy('/link_attacher_node/attach',
                                    Attach)
    attach_srv.wait_for_service()
    rospy.loginfo("Created ServiceProxy to /link_attacher_node/attach")

    # Link them
    rospy.loginfo("Attaching cube1 and cube2")
    req = AttachRequest()
    req.model_name_1 = "/"
    req.link_name_1 = "robotiq_85_left_finger_tip_link"
    req.model_name_2 = "cube1"
    req.link_name_2 = "link"

    attach_srv.call(req)
    # From the shell:
    """
rosservice call /link_attacher_node/attach "model_name_1: 'cube1'
link_name_1: 'link'
model_name_2: 'cube2'
link_name_2: 'link'"
    """

    rospy.loginfo("Attaching cube2 and cube3")
    req = AttachRequest()
    req.model_name_1 = "/"
    req.link_name_1 = "robotiq_85_right_finger_tip_link"
    req.model_name_2 = "cube1"
    req.link_name_2 = "link"

    attach_srv.call(req)

    #rospy.loginfo("Attaching cube3 and cube1")
    #req = AttachRequest()
    #req.model_name_1 = "cube3"
    #req.link_name_1 = "link"
    #req.model_name_2 = "cube1"
    #req.link_name_2 = "link"

    #attach_srv.call(req)

def detach():
    #rospy.init_node('demo_detach_links')
    rospy.loginfo("Creating ServiceProxy to /link_attacher_node/detach")
    attach_srv = rospy.ServiceProxy('/link_attacher_node/detach',
                                    Attach)
    attach_srv.wait_for_service()
    rospy.loginfo("Created ServiceProxy to /link_attacher_node/detach")

    # Link them
    rospy.loginfo("Detaching cube1 and cube2")
    req = AttachRequest()
    req.model_name_1 = "husky1"
    req.link_name_1 = "robotiq_85_left_finger_tip_link"
    req.model_name_2 = "cube1"
    req.link_name_2 = "link"

    attach_srv.call(req)
    # From the shell:
    """
rosservice call /link_attacher_node/detach "model_name_1: 'cube1'
link_name_1: 'link'
model_name_2: 'cube2'
link_name_2: 'link'"
    """

    rospy.loginfo("Attaching cube2 and cube3")
    req = AttachRequest()
    req.model_name_1 = "/"
    req.link_name_1 = "robotiq_85_right_finger_tip_link"
    req.model_name_2 = "cube1"
    req.link_name_2 = "link"

    attach_srv.call(req)

    #rospy.loginfo("Attaching cube3 and cube1")
    #req = AttachRequest()
    #req.model_name_1 = "cube3"
    #req.link_name_1 = "link"
    #req.model_name_2 = "cube1"
    #req.link_name_2 = "link"

    #attach_srv.call(req)



def move():
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('move_group_python', anonymous=True)


    robot = moveit_commander.RobotCommander()
    scene = moveit_commander.PlanningSceneInterface()
    group = moveit_commander.MoveGroupCommander('arm')
    group1 = moveit_commander.MoveGroupCommander('gripper')
    diaplay_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path',moveit_msgs.msg.DisplayTrajectory,queue_size=1)


    #pose_target = geometry_msgs.msg.Pose()
    #pose_target.orientation.w = 0.0
    #pose_target.position.x = 0.6
    #pose_target.position.y = 0.11
    #pose_target.position.z = 0.45
    #group.set_pose_target(pose_target)

    #rospy.sleep(5)

    joint_goal = group.get_current_joint_values()
    print(joint_goal)
    #joint_goal[0] = 0
    #joint_goal[1] = -pi/3
    #joint_goal[2] = 0
    #joint_goal[3] = -pi/2
    #joint_goal[4] = 0
    #joint_goal[5] = pi/3

    joint_gripper = [0.027540172282155825]
    group1.go(joint_gripper, wait=True)
    group1.stop()

    joint_goal = [-1.5548236021561115, -0.68284077409866, -1.4672833665520275, -1.2319079027555944, -0.02274701380800222, -2.895747152358406]
    group.go(joint_goal, wait=True)
    #print joint_goal[0]
    group.stop()

    joint_goal = [-2.5041618590649963, -2.9222071668808605, 1.9334752483549988, -2.123288662124964, 0.9932623363587714, -3.140420314353408]
    group.go(joint_goal, wait=True)
    #print joint_goal[0]
    group.stop()

    joint_gripper = [0.015]
    group1.go(joint_gripper, wait=True)
    group1.stop()

    #attach()

    joint_goal = [2.540440584695485, -1.9981821130828583, 1.8972598416743387, 0.10042318783493442, 0.9684531626420737, -0.0006339319476427656]
    group.go(joint_goal, wait=True)
    #print joint_goal[0]
    group.stop()

    joint_gripper = [0.027540172282155825]
    group1.go(joint_gripper, wait=True)
    group1.stop()

    #detach()

    #rospy.sleep(1)

    #p = PoseStamped()
    #p.header.frame_id = robot.get_planning_frame()
    # p.header.frame_id = "base_link"
    #p.pose.position.x = 1.0717
    #p.pose.position.y = -0.0171
    #p.pose.position.z = 0.6
    #p.pose.orientation.w = 1.0
    #scene.add_box("table", p, (1, 1, 0.01))

    #plan1 = group.plan()

    #rospy.sleep(5)
    #group.go(wait = True)

    moveit_commander.roscpp_shutdown()

if __name__ == '__main__':
    attach()

