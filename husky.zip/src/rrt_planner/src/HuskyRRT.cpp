/*
Author: Sarvesh Sortee
Original Python Code: Arup Sadhu
*/

#include <pluginlib/class_list_macros.h>
#include <rrt_planner/HuskyRRT.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
PLUGINLIB_EXPORT_CLASS(rrt_husky::RRTPlannerROS, nav_core::BaseGlobalPlanner);

namespace rrt_husky
{
    RRTPlannerROS::RRTPlannerROS() : costmap_ros_(nullptr), initialized_(false) {}

    RRTPlannerROS::RRTPlannerROS(std::string name,
                                 costmap_2d::Costmap2DROS *costmap_ros) : costmap_ros_(costmap_ros)
    {
        initialize(name, costmap_ros);
    }

    void RRTPlannerROS::initialize(std::string name,
                                   costmap_2d::Costmap2DROS *costmap_ros)
    {
        if (!initialized_)
        {
            costmap_ros_ = costmap_ros;
            costmap_ = costmap_ros_->getCostmap();

            ros::NodeHandle node("~/" + name);
            nh_ = node;
            world_model_ = new base_local_planner::CostmapModel(*costmap_);

            plan_pub_ = nh_.advertise<nav_msgs::Path>("plan", 1);

            nh_.getParam("step_size", expand_dis_);
            nh_.getParam("delta", step_collision_);
            nh_.getParam("goal_radius", goal_radius_);
            nh_.getParam("max_iterations", max_iter_);
            nh_.getParam("path_resolution", path_resolution_);
            nh_.getParam("max_control", max_control_);
            nh_.getParam("goal_sample_rate", goal_sample_rate_);
            //nh_.getParam("robot_inflation", robot_inflation_);
            nh_.getParam("octomap_inflation", octomap_inflation_);
            nh_.getParam("use_octomap", use_octomap_);

            map_width_cells_ = costmap_->getSizeInCellsX();
            map_height_cells_ = costmap_->getSizeInCellsY();

            if (use_octomap_)
            {
                ROS_INFO("Using Octomap for collision checking.");
                octomap_sub_ = nh_.subscribe("/octomap_full", 1, &RRTPlannerROS::octomapCallback, this);
                octomap_pub_ = nh_.advertise<octomap_msgs::Octomap>("/inflated_map", 1);
            }
            else
            {
                ROS_INFO("Using 2D Occupancy Grid for collision checking.");
                for (unsigned int iy = 0; iy < map_height_cells_; iy++)
                {
                    for (unsigned int ix = 0; ix < map_width_cells_; ix++)
                    {
                        unsigned char cost = static_cast<int>(costmap_->getCost(ix, iy));
                        if (cost >= 128 && cost != 255) //treating unknown as free
                            obstacle_map_.push_back(false); //false meaning not free
                        else
                            obstacle_map_.push_back(true);
                    }
                }
            }

            ROS_INFO("Step size: %.2f, goal radius: %.2f, step for collision checking: %.2f, max "
                     "iterations: %d",
                     expand_dis_, goal_radius_, step_collision_,
                     max_iter_);
            current_iter_ = 0;
            //ROS_ERROR("Costmap global frame ID is: %s",costmap_ros_->getGlobalFrameID().c_str());

            ROS_INFO("Map size is (%.2f,%.2f) in (%d,%d) grid", costmap_->getSizeInMetersX(), costmap_->getSizeInMetersY(),
                     map_width_cells_, map_height_cells_);

            ROS_INFO("RRT planner initialized successfully");
            initialized_ = true;
        }
        else
        {
            ROS_WARN("RRT planner has already been initialized. Ignoring.");
        }
    }

    void RRTPlannerROS::octomapCallback(const octomap_msgs::OctomapConstPtr &octomap)
    {
        octomap::AbstractOcTree *absTree = octomap_msgs::fullMsgToMap(*octomap);
        octree_ = dynamic_cast<octomap::OcTree *>(absTree);

        octomap_resolution_ = octree_->getResolution();
        ROS_INFO("Octomap loaded with %lu nodes and resolution %.2f", octree_->calcNumNodes(), octomap_resolution_);
        inflated_octree_ = octree_->create();

        //inflated_octree_->setResolution(octomap_resolution_);

        createOctomapInflator(octomap_inflation_);
        inflateOctomap(inflated_octree_);

        ROS_INFO("Inflated Octomap has %lu nodes and resolution %.2f", inflated_octree_->calcNumNodes(), inflated_octree_->getResolution());
        /* octomap_msgs::Octomap octo_msg;
        octomap_msgs::binaryMapToMsg(*inflated_octree_,octo_msg);
        octo_msg.header.frame_id = "map";
        octo_msg.header.stamp = ros::Time::now();
        octomap_pub_.publish(octo_msg); */
        /* octomap::AbstractOccupancyOcTree* octree = NULL;
        octree = dynamic_cast<octomap::AbstractOccupancyOcTree*>(inflated_octree_);
        if(!octree_->writeBinary("maze_inflated.ot"))
            ROS_WARN("Could not write to file");

        ROS_INFO("Wrote to file"); */
    }

    void RRTPlannerROS::createOctomapInflator(float &radius)
    {
        inflator_.clear();
        octomap::point3d p;
        int r = ceil(radius / octomap_resolution_);

        for (int x = -r; x <= r; x++)
        {
            for (int y = -r; y <= r; y++)
            {
                for (int z = -r; z <= r; z++)
                {
                    p = octomap::point3d(x * octomap_resolution_, y * octomap_resolution_, z * octomap_resolution_);
                    if (p.norm() <= radius)
                    {
                        inflator_.push_back(p);
                    }
                }
            }
        }
    }

    void RRTPlannerROS::createOctomapInflator(float &radius, float &height)
    {
        inflator_.clear();
        octomap::point3d p;
        int r = ceil(radius / octomap_resolution_);
        int h = ceil(height / octomap_resolution_);

        for (int x = -r; x <= r; x++)
        {
            for (int y = -r; y <= r; y++)
            {
                p = octomap::point3d(x * octomap_resolution_, y * octomap_resolution_, 0);
                if (p.norm() <= radius)
                {
                    inflator_.push_back(p);
                }
            }
        }
    }

    void RRTPlannerROS::inflateOctomap(octomap::OcTree *&map)
    {
        octomap::point3d origin, point_in_inflated;
        bool is_origin_occupied;
        octomap::OcTreeNode *origin_node, *node;

        map->clear();

        for (octomap::OcTree::leaf_iterator i = octree_->begin_leafs(), end = octree_->end_leafs();
             i != end;
             i++)
        {

            origin = i.getCoordinate();
            origin_node = octree_->search(origin);
            is_origin_occupied = octree_->isNodeOccupied(origin_node);

            if (is_origin_occupied)
            {
                //ROS_WARN("Adding inflator");
                for (int j = 0; j < inflator_.size(); j++)
                {
                    point_in_inflated = origin + inflator_.at(j);
                    map->updateNode(point_in_inflated, true);
                }
                map->updateNode(origin, true);
            }
            else
            {
                //ROS_WARN("In else");
                node = map->search(origin);
                if (node == nullptr)
                {
                    map->updateNode(origin, false);
                }
                else if (!map->isNodeOccupied(node))
                {
                    map->updateNode(origin, false);
                }
            }
        }
    }

    bool RRTPlannerROS::makePlan(const geometry_msgs::PoseStamped &start,
                                 const geometry_msgs::PoseStamped &goal,
                                 std::vector<geometry_msgs::PoseStamped> &plan)
    {
        //boost::mutex::scoped_lock lock(mutex_);
        if (!initialized_)
        {
            ROS_ERROR("RRTPlannerROS has not been initialized!");
            return false;
        }

        tf2::Quaternion q;
        tf2::fromMsg(start.pose.orientation, q);
        tf2Scalar roll, pitch, yaw;
        tf2::Matrix3x3(q).getRPY(roll, pitch, yaw);

        origin_x_ = start.pose.position.x;
        origin_y_ = start.pose.position.y;
        origin_yaw_ = (float)yaw;
        origin_v_ = 0;
        origin_phi_ = 0;

        ROS_INFO("Starting Pose: \n x:%.2f, y:%.2f, yaw:%.2f ", origin_x_, origin_y_, origin_yaw_);

        tf2::fromMsg(goal.pose.orientation, q);
        tf2::Matrix3x3(q).getRPY(roll, pitch, yaw);

        bool within_bounds;
        unsigned int map_x, map_y;

        goal_x_ = goal.pose.position.x;
        goal_y_ = goal.pose.position.y;
        goal_yaw_ = (float)yaw;
        goal_v_ = 0;
        goal_phi_ = 0;
        

        ROS_INFO("Goal Pose: \n x:%.2f, y:%.2f, yaw:%.2f ", goal_x_, goal_y_, goal_yaw_);
        within_bounds = costmap_->worldToMap(goal_x_, goal_y_, map_x, map_y);
        if(!within_bounds){
            ROS_WARN("Goal is not within map bounds");
            return false;
        }
        else
        {
            if (!obstacle_map_.at(map_y * map_width_cells_ + map_x))
            {
                ROS_WARN("Goal is occupied. Aborting");
                return false;
            }
            
        }

        plan.clear();
        current_iter_ = 0;
        node_list_.clear();

        rrt_husky::RRTNode root_node(origin_x_, origin_y_, origin_yaw_, origin_v_, origin_phi_, 0, -1);
        addNodeToList(root_node);
        ROS_INFO("Goal FrameID: %s, Costmap frameID: %s", goal.header.frame_id.c_str(), costmap_ros_->getGlobalFrameID().c_str());
        if (goal.header.frame_id != costmap_ros_->getGlobalFrameID())
        {
            ROS_ERROR("Goal and map frames do not match. Goal frameID: %s, Costmap frameID:%s",
                      goal.header.frame_id.c_str(), costmap_ros_->getGlobalFrameID().c_str());
            return false;
        }

        //ROS_WARN("Trying to find a path");
        int goal_index = RRTPlannerROS::findPath(start, goal);

        plan = RRTPlannerROS::buildPlan(goal_index, start, goal);

        if (plan.size() > 1)
        {
            ROS_INFO("A path was determined");
            publishPlan(plan);
            return true;
        }
        else
        {
            ROS_INFO("No path was found");
            return false;
        }
    }
    void RRTPlannerROS::publishPlan(std::vector<geometry_msgs::PoseStamped> &plan)
    {
        if (!initialized_)
        {
            ROS_ERROR("This planner has not been initialized yet, but it is being used, please call initialize() before use");
            return;
        }

        nav_msgs::Path path;
        path.poses.resize(plan.size());

        if (plan.empty())
        {
            path.header.frame_id = costmap_ros_->getGlobalFrameID();
            path.header.stamp = ros::Time::now();
        }
        else
        {
            path.header.frame_id = plan[0].header.frame_id;
            path.header.stamp = plan[0].header.stamp;
        }

        for (unsigned int i = 0; i < plan.size(); i++)
        {
            path.poses[i] = plan[i];
        }
        plan_pub_.publish(path);
    }

    std::pair<float, float> RRTPlannerROS::getRandomPoint()
    {
        std::pair<float, float> point;
        boost::random::random_device r;
        boost::random::random_device r2;
        boost::random::mt19937 generartor(r());
        boost::random::mt19937 generator2(r2());
        float width, height;
        int p;
        width = costmap_->getSizeInMetersX();
        height = costmap_->getSizeInMetersY();
        //boost::random::uniform_real_distribution<> x(-width, width);
        //boost::random::uniform_real_distribution<> y(-height, height);

        //IMPORTANT: Use map limit coordinates in next 2 lines
        boost::random::uniform_real_distribution<> x(-15, 15);
        boost::random::uniform_real_distribution<> y(-10, 10);
        boost::random::uniform_int_distribution<> pd(0, 100);
        p = pd(generator2);
        if (p > goal_sample_rate_)
        {
            point.first = x(generartor);
            point.second = y(generartor);
        }
        else
        {
            point.first = goal_x_;
            point.second = goal_y_;
        }

        return point;
    }

    float RRTPlannerROS::getRandomYaw()
    {
        float yaw;
        boost::random::random_device r;
        boost::random::mt19937 generartor(r());
        boost::random::uniform_real_distribution<> Y(-3.14159, 3.14159);

        yaw = Y(generartor);
        return yaw;
    }
    std::pair<float, float> RRTPlannerROS::getRandomControl()
    {
        std::pair<float, float> control;
        boost::random::random_device r;
        boost::random::mt19937 generartor(r());
        boost::random::uniform_real_distribution<> v(0, 5);
        boost::random::uniform_real_distribution<> phi(-1.3, 1.3);

        control.first = v(generartor);
        control.second = phi(generartor);
        return control;
    }

    int RRTPlannerROS::findPath(const geometry_msgs::PoseStamped &start,
                                const geometry_msgs::PoseStamped &goal)
    {

        //ROS_WARN("In findPath");
        int goal_index = -1;
        current_iter_ = 0;
        bool done = false;
        while (!done && current_iter_ < max_iter_)
        {
            ROS_INFO("Iteration %d", current_iter_);
            std::pair<float, float> rnd_loc = getRandomPoint();
            float rnd_yaw = getRandomYaw();

            int near_node = getNearestNode(rnd_loc, rnd_yaw);

            // Steering towards sampled node
            if (steerTowardsPoint(near_node, rnd_loc, rnd_yaw))
            {
                current_iter_++;
                int new_node = node_list_.back().getIndex();

                done = goalReached(new_node);
                if (done)
                {
                    ROS_INFO("Goal reached in %d iterations, index of goal node is %d", current_iter_, new_node);
                    goal_index = new_node;
                }
            }
        }
        if (current_iter_ > max_iter_)
        {
            ROS_WARN("Max iterations reached. No path found!");
        }

        return goal_index;
    }

    bool RRTPlannerROS::steerTowardsPoint(int nearest_node, std::pair<float, float> random_point, float random_yaw)
    {
        //ROS_WARN("Steering towards sampled point");

        std::pair<float, float> loc_near = node_list_.at(nearest_node).getLocation();
        float yaw_near = normalizeAngle(node_list_.at(nearest_node).getYaw());

        float yaw_rnd = normalizeAngle(random_yaw);

        float d, step_size;
        d = calcDistance(loc_near, yaw_near, random_point, yaw_rnd);
        if (d > expand_dis_)
        {
            step_size = expand_dis_;
        }
        else
        {
            step_size = d;
        }

        int n_expand = (int)floor(step_size / path_resolution_);
        float vehicle_length = 0.8; // wheel base of the vehicle
        float yaw_dot, x_dot, y_dot, dx, dy, dyaw;
        float x_curr, y_curr, yaw_curr, dm, x_new, y_new, yaw_new;
        x_curr = loc_near.first;
        y_curr = loc_near.second;
        yaw_curr = yaw_near;
        float dmmin;

        for (int i = 0; i < n_expand; i++)
        {
            dmmin = std::numeric_limits<float>::infinity();

            for (int j = 0; j < max_control_; j++)
            {
                std::pair<float, float> rnd_ctrl = getRandomControl();
                yaw_dot = rnd_ctrl.first * tan(rnd_ctrl.second) / vehicle_length;
                x_dot = rnd_ctrl.first * cos(yaw_curr);
                y_dot = rnd_ctrl.first * sin(yaw_curr);
                dx = path_resolution_ * x_dot;
                dy = path_resolution_ * y_dot;
                dyaw = path_resolution_ * yaw_dot;
                //dyaw = atan2(dy,dx) - yaw_curr;
                dm = pow(dx, 2) + pow(dy, 2) + pow(dyaw, 2);
                //dm = sqrt(dm);

                if (dm < dmmin)
                {
                    dmmin = dm;
                    x_new = x_curr + dx;
                    y_new = y_curr + dy;
                    yaw_new = yaw_curr + dyaw;
                }
            }
            x_curr = x_new;
            yaw_curr = yaw_new;
            y_curr = y_new;
        }
        std::pair<float, float> suggested_point(x_curr, y_curr);
        float suggested_yaw = yaw_curr;

        if (isSafe(loc_near, suggested_point)) // Check if straight line between nearest node and suggested node is collision free
        {
            rrt_husky::RRTNode reached_node(suggested_point.first, suggested_point.second,
                                            suggested_yaw, 0, 0, node_list_.size(), nearest_node);
            ROS_INFO("New node with pose x:%.2f y:%.2f yaw %.2f added at index % d",
                     suggested_point.first, suggested_point.second, suggested_yaw, reached_node.getIndex());

            addNodeToList(reached_node);
            return true;
        }
        else
        {
            ROS_INFO("Not safe");
        }

        return false;
    }

    bool RRTPlannerROS::isSafe(std::pair<float, float> start_loc, std::pair<float, float> end_loc)
    {
        unsigned int map_x, map_y;
        bool within_bounds;

        within_bounds = costmap_->worldToMap(end_loc.first, end_loc.second, map_x, map_y);
        if (!within_bounds)
        {
            ROS_WARN("Point not within Map bounds (%d,%d)", map_x, map_y);
            return false;
        }
        if (use_octomap_)
        {
            if (hitsObstacle(end_loc))
            {
                ROS_INFO("End point hits obstacle");
                return false;
            }
        }
        else
        {
            //ROS_INFO("In IsSafe (%d,%d)", map_x, map_y);
            if (!obstacle_map_.at(map_y * map_width_cells_ + map_x))
            {
                ROS_INFO("End point not safe");
                return false;
            }
        }

        float theta = atan2(end_loc.second - start_loc.second, end_loc.first - start_loc.first);
        std::pair<float, float> curr_loc = start_loc;

        while (calcEuclideanDistance(curr_loc, end_loc) > step_collision_)
        {
            curr_loc.first += step_collision_ * cos(theta);
            curr_loc.second += step_collision_ * sin(theta);
            if (use_octomap_)
            {
                if (hitsObstacle(curr_loc))
                {
                    ROS_INFO("Intermediate point hits obstacle");
                    return false;
                }
            }
            else
            {

                costmap_->worldToMap(curr_loc.first, curr_loc.second, map_x, map_y);
                ROS_INFO("In IsSafe 1 (%d,%d)", map_x, map_y);
                if (!obstacle_map_.at(map_y * map_width_cells_ + map_x))
                {
                    ROS_INFO("Point not safe");
                    return false;
                }
            }
        }
        return true;
    }

    bool RRTPlannerROS::hitsObstacle(std::pair<float, float> loc)
    {
        bool occupied;
        octomap::OcTreeNode *node = inflated_octree_->search(loc.first, loc.second, 0.1322);
        if (node != nullptr)
        {
            occupied = inflated_octree_->isNodeOccupied(node);
            if (occupied)
                ROS_WARN("Node occupied");
            return occupied;
        }
        else
        {
            ROS_WARN("Node not found");
            return false;
        }

        /* float twopi = 3.1415 * 2;
        int i = 40;
        float theta;
        double x, y, z;
        bool occupied;
        z = 0.132278;
        for (int j = 0; j < i; j++)
        {
            theta = j * twopi / i;
            x = loc.first + robot_inflation_ * cos(theta);
            y = loc.second + robot_inflation_ * sin(theta);
            octomap::OcTreeNode *testNode = octree_->search(x, y, z); //0.1322 is height of base_link on flat surface
            if (testNode != nullptr)
            {
                occupied = octree_->isNodeOccupied(testNode);
                if (occupied)
                    ROS_ERROR("Node occupied");
                return occupied;
            }
            else
            {
                ROS_WARN("Node not found");
                return false;
            }
        }
        return false; */
    }

    int RRTPlannerROS::getNearestNode(std::pair<float, float> location, float yaw)
    {
        int nearest = -1;
        float min_distance = std::numeric_limits<float>::infinity();
        float distance;

        for (rrt_husky::RRTNode n : node_list_)
        {
            distance = RRTPlannerROS::calcDistance(n.getLocation(), n.getYaw(), location, yaw);
            if (distance < min_distance)
            {
                min_distance = distance;
                nearest = n.getIndex();
            }
        }
        return nearest;
    }

    float RRTPlannerROS::calcEuclideanDistance(std::pair<float, float> start, std::pair<float, float> end)
    {
        float distance2;
        distance2 = pow(start.first - end.first, 2) + pow(start.second - end.second, 2);

        return sqrt(distance2);
    }

    float RRTPlannerROS::calcDistance(std::pair<float, float> start_loc, float start_yaw, std::pair<float, float> end_loc, float end_yaw)
    {
        float distance2;
        start_yaw = normalizeAngle(start_yaw);
        end_yaw = normalizeAngle(end_yaw);
        distance2 = pow(start_loc.first - end_loc.first, 2) + pow(start_loc.second - end_loc.second, 2);
        distance2 = distance2 + pow(start_yaw - end_yaw, 2);

        return sqrt(distance2);
    }
    float RRTPlannerROS::calcDistance(int start_node, int end_node)
    {
        rrt_husky::RRTNode start = node_list_.at(start_node);
        rrt_husky::RRTNode end = node_list_.at(end_node);
        float distance2;
        distance2 = pow(start.getLocation().first - end.getLocation().first, 2);
        distance2 += pow(start.getLocation().second - end.getLocation().second, 2);
        distance2 += pow(normalizeAngle(start.getYaw()) - normalizeAngle(end.getYaw()), 2);
        return sqrt(distance2);
    }

    float RRTPlannerROS::normalizeAngle(float x)
    {
        float y = fmod(x + 3.14159, 6.28318);
        if (y < 0)
        {
            y += 6.28318;
        }
        return y - 3.14159;
    }
    bool RRTPlannerROS::goalReached(int node)
    {
        std::pair<float, float> goal(goal_x_, goal_y_);

        std::pair<float, float> node_loc = node_list_.at(node).getLocation();

        float goal_dis = calcEuclideanDistance(goal, node_loc);

        if (goal_dis <= goal_radius_)
        {
            return true;
        }
        return false;
    }

    std::vector<geometry_msgs::PoseStamped> RRTPlannerROS::buildPlan(int goal_index,
                                                                     const geometry_msgs::PoseStamped &start,
                                                                     const geometry_msgs::PoseStamped &goal)
    {
        std::vector<geometry_msgs::PoseStamped> plan;
        if (goal_index == -1)
        {
            return plan;
        }

        std::deque<int> index_path;
        int curr_index = goal_index;
        while (curr_index > 0)
        {
            index_path.push_front(curr_index);
            curr_index = node_list_.at(curr_index).getParent();
        }
        index_path.push_front(0);

        for (int i : index_path)
        {
            if (i == 0)
            {
                plan.push_back(start);
            }
            else
            {
                geometry_msgs::PoseStamped p;
                p.header.frame_id = "map";
                p.pose.position.x = node_list_.at(i).getLocation().first;
                p.pose.position.y = node_list_.at(i).getLocation().second;
                p.pose.position.z = 0.0;

                tf2::Quaternion q;
                q.setRPY(0.0, 0.0, node_list_.at(i).getYaw());
                p.pose.orientation = tf2::toMsg(q);

                plan.push_back(p);
            }
        }
        plan.push_back(goal);
        unsigned int map_x, map_y;
        for (geometry_msgs::PoseStamped p : plan)
        {
            costmap_->worldToMap(p.pose.position.x, p.pose.position.y, map_x, map_y);
            ROS_INFO("Plan:: x:%.2f (%d), y:%.2f (%d)", p.pose.position.x, map_x,
                     p.pose.position.y, map_y);
        }
        return plan;
    }

} // namespace rrt_husky
