/*Author: Sarvesh Sortee*/
#include "rrt_planner/RRTNode.h"

namespace rrt_husky
{
    RRTNode::RRTNode(float x, float y, float yaw, float v, float phi, int index, int parent)
    {
        x_ = x;
        y_ = y;
        yaw_ = yaw;
        v_ = v;
        phi_ = phi;
        index_ = index;
        parent_ = parent;
    }

    void RRTNode::setLocation(float x, float y)
    {
        x_ = x;
        y_ = y;
    }

    void RRTNode::setYaw(float yaw)
    {
        yaw_ = yaw;
    }

    void RRTNode::setControl(float v, float phi)
    {
        v_ = v;
        phi_ = phi;
    }

    void RRTNode::setIndex(int index)
    {
        index_ = index;
    }

    void RRTNode::setParent(int parent)
    {
        parent_ = parent;
    }

    std::pair<float,float> RRTNode::getLocation(){
        return std::pair<float,float>(x_,y_);
    }
    float RRTNode::getYaw(){
        return yaw_;
    }
    std::pair<float,float> RRTNode::getControl(){
        return std::pair<float,float>(v_,phi_);
    }
    int RRTNode::getIndex(){
        return index_;
    }

    int RRTNode::getParent(){
        return parent_;
    }
} // namespace rrt_husky
