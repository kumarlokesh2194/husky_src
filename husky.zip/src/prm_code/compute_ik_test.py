#!/usr/bin/env python

import rospy
from moveit_msgs.srv import GetPositionIK
from moveit_msgs.srv import GetPositionIKRequest
from moveit_msgs.srv import GetPositionIKResponse
from geometry_msgs.msg import PoseStamped, TransformStamped
import geometry_msgs
import moveit_commander
import sys
from moveit_msgs.msg import RobotState
from geometry_msgs.msg import Transform, PoseStamped
from sensor_msgs.msg import JointState
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from geometry_msgs.msg import PoseStamped, PoseWithCovariance
from math import pi
from gazebo_ros_link_attacher.srv import Attach, AttachRequest, AttachResponse
from octomap_msgs.srv import BoundingBoxQuery
from nav_msgs.msg import Odometry
import explore
from clear_bbx_with_pick import ClearBbx
from std_srvs.srv import Empty


class GetIK:
    def __init__(self, group="arm", ik_timeout=5.0, ik_attempts=100,
                 avoid_collisions=False):

     	self.points = [[-0.2298365564038522, -0.44883969129608514, 0.3567462304009662, -3.0047308626086506, -0.6868121273332596, -0.07194863310824366],
     	[-0.22983655640385212, -0.5248113739514862, 0.37657567350883675, -2.6098299958857485, -0.7320552877766119, -0.33010729989368875],
     	[-0.22981239589841534, -0.43041061855281243, 0.3468934442675529, -3.0916931883025347, -0.8507141614282971, -0.019490893690639634],
     	[-0.22981239589841548, -0.4401017578866485, 0.35227982612621234, -3.046382875189012, -1.791223900368312, -0.07865280908264202],
     	[-0.22981241314922285, -0.5246812461345848, 0.37656150854235676, -2.6109333513726214, -1.8045677746417077, 0.006761463700672583],
     	[-0.2298179282104822, -0.42034617694520493, 0.3405956453061256, -3.1386923973828527, -1.7840788648277148, -0.09673186317788576],
     	[-0.2298178591852189, -0.5530056122488788, 0.3732394810950672, -2.4345520431768968, -1.365112097830899, -0.2413607446434225],
     	[-0.2298178591852189, -0.4220674880655459, 0.3416829370302992, -3.1307726125989923, -1.266600845638239, -0.08635828274440525],
     	[-0.5352159702373716, -0.7333696480217581, -0.112353145696371, -1.2877491694990073, -1.3188164163164076, -0.5636738986978801],
     	[-0.5352159702373723, -0.6966363202254604, -0.22857478293066766, -0.864300652253486, -0.8998113303572558, -0.7212823432605723],
     	[-0.5352159702373711, -0.7397887076264897, -0.06884745457174778, -1.4787427871843306, -1.5667131366115699, -0.543524167262544]]

        self.clear_octomap_srv = rospy.ServiceProxy("husky1/clear_octomap",Empty)

        rospy.loginfo("Initalizing GetIK...")
        self.object_pose = []
        rospy.Subscriber("Object_pose",Odometry,self.callback_pose)
        self.pose_target = PoseStamped()
        self.group_name = group
        self.ik_timeout = ik_timeout
        self.ik_attempts = ik_attempts
        self.avoid_collisions = avoid_collisions
        rospy.loginfo("Computing IKs for group: " + self.group_name)
        rospy.loginfo("With IK timeout: " + str(self.ik_timeout))
        rospy.loginfo("And IK attempts: " + str(self.ik_attempts))
        rospy.loginfo("Setting avoid collisions to: " +
                      str(self.avoid_collisions))
        self.ik_srv = rospy.ServiceProxy('husky1/compute_ik',
                                         GetPositionIK)
        rospy.loginfo("Waiting for /compute_ik service...")
        self.ik_srv.wait_for_service()
        rospy.loginfo("Connected!")
        # self.bbx_clear_service = rospy.ServiceProxy('husky1/octomap_server/clear_bbx',BoundingBoxQuery)
        # rospy.loginfo("Waiting for /clear_bbx service...")
        # self.bbx_clear_service.wait_for_service()
        # rospy.loginfo("Connected!")
        self.all_check_poses = []
        self.sucess = 0
        self.collision_object_pose = []


    def callback_pose(self,msg):
        self.pose_target.header.frame_id = "base_link"
        self.pose_target.pose.orientation.w = 0.7071068
        self.pose_target.pose.orientation.x = 0
        self.pose_target.pose.orientation.y = 0
        self.pose_target.pose.orientation.z = -0.7071068
        self.pose_target.pose.position.x = msg.pose.pose.position.x - 0.1
        self.pose_target.pose.position.y = msg.pose.pose.position.y
        self.pose_target.pose.position.z = msg.pose.pose.position.z

    def get_ik(self,
               group=None,
               ik_timeout=None,
               ik_attempts=None,
               avoid_collisions=True):

        tf = JointState()
        rs = RobotState()
        c = 0

        while self.sucess!=1:
            joint_goal = self.points[c]
            self.group1.go(joint_goal, wait=True)
            tf.name = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']
            tf.position =  [0,0,0,0,0,0]
            tf.header.frame_id = "base_link"
            rs.joint_state = tf
            print(self.pose_target)
            if group is None:
                group = self.group_name
            if ik_timeout is None:
                ik_timeout = self.ik_timeout
            if ik_attempts is None:
                ik_attempts = self.ik_attempts
            if avoid_collisions is None:
                avoid_collisions = self.avoid_collisions
            req = GetPositionIKRequest()
            req.ik_request.group_name = group
            req.ik_request.pose_stamped = self.pose_target
            req.ik_request.timeout = rospy.Duration(ik_timeout)
            req.ik_request.attempts = ik_attempts
            req.ik_request.avoid_collisions = avoid_collisions
            req.ik_request.robot_state = rs
            c+=1

            try:
                resp = self.ik_srv.call(req)
                i_1, i_2, i_3, i_4, i_5, i_6 = 0,0,0,0,0,0
                if resp.error_code.val == 1:
                    self.collision_object_pose.append([req.ik_request.pose_stamped.pose.position.x,req.ik_request.pose_stamped.pose.position.y,req.ik_request.pose_stamped.pose.position.z])
                    print("------------",self.collision_object_pose)
                    goal_samples = []
                    samples = []
                    for i in range(0,len(resp.solution.joint_state.name)):
                        if resp.solution.joint_state.name[i] == "shoulder_pan_joint":
                            i_1 = i
                        elif resp.solution.joint_state.name[i] == "shoulder_lift_joint":
                            i_2 = i
                        elif resp.solution.joint_state.name[i] == "elbow_joint":
                            i_3 = i
                        elif resp.solution.joint_state.name[i] == "wrist_1_joint":
                            i_4 = i
                        elif resp.solution.joint_state.name[i] == "wrist_2_joint":
                            i_5 = i
                        elif resp.solution.joint_state.name[i] == "wrist_3_joint":
                            i_6 = i

                    position = resp.solution.joint_state.position
                    print(resp)
                    goal_samples.append([position[i_1],position[i_2],position[i_3],position[i_4],position[i_5],position[i_6]])
                    print("<----- computed joint_state  ----->")
                    print(goal_samples)
                    self.sucess = 1

            except rospy.ServiceException as e:
                rospy.logerr("Service exception: " + str(e))
                resp = GetPositionIKResponse()
                resp.error_code = 99999  # Failure


        return goal_samples

    def attach(self):
        #rospy.init_node('demo_attach_links')
        rospy.loginfo("Creating ServiceProxy to /link_attacher_node/attach")
        attach_srv = rospy.ServiceProxy('/link_attacher_node/attach',
                                        Attach)
        attach_srv.wait_for_service()
        rospy.loginfo("Created ServiceProxy to /link_attacher_node/attach")

        rospy.loginfo("Attaching")
        req = AttachRequest()
        req.model_name_1 = "husky1"
        req.link_name_1 = "wrist_3_link"
        req.model_name_2 = "cube10"
        req.link_name_2 = "base_link"

        attach_srv.call(req)


    def detach(self):
        #rospy.init_node('demo_detach_links')
        rospy.loginfo("Creating ServiceProxy to /link_attacher_node/detach")
        attach_srv = rospy.ServiceProxy('/link_attacher_node/detach',
                                        Attach)
        attach_srv.wait_for_service()
        rospy.loginfo("Created ServiceProxy to /link_attacher_node/detach")

        rospy.loginfo("Detaching")
        req = AttachRequest()
        req.model_name_1 = "husky1"
        req.link_name_1 = "wrist_3_link"
        req.model_name_2 = "cube10"
        req.link_name_2 = "base_link"

        attach_srv.call(req)


    def move(self):

        moveit_commander.roscpp_initialize(sys.argv)
        rospy.init_node('move_group_python1', anonymous=True)

        self.robot1 = moveit_commander.RobotCommander(robot_description = "husky1/robot_description")
        self.scene1 = moveit_commander.PlanningSceneInterface("husky1")
        self.group1 = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = "arm")
        # group2 = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = "gripper")

        goal_samples = self.get_ik()
        print("from move node",goal_samples)
        x,y,z = self.get_pick_pose()
        clear_octo_for_pick = ClearBbx()
        clear_octo_for_pick.clear_bbx(x,y,z)

        joint_goal = goal_samples[0]
        self.group1.go(joint_goal, wait=True)

        rospy.sleep(1)

        self.attach()
        rospy.sleep(1)
        self.add_collision_object()
        rospy.sleep(1)
        self.attach_collision_object()
        rospy.sleep(3)

        joint_goal = [2.8679971107859212, -0.021237496915359252, 0.3348694686768484, -1.887715811116879, -1.5042659159617278, -0.24017760979990443]
        self.group1.go(joint_goal, wait=True)

        # self.detach()
        rospy.sleep(1)
        self.remove_collision_object()
        rospy.sleep(1)
        self.clear_octomap_srv.call()


        moveit_commander.roscpp_shutdown()

    def get_pick_pose(self):
        x = self.collision_object_pose[0][0]
        y = self.collision_object_pose[0][1]
        z = self.collision_object_pose[0][2]
        return (x,y,z)

    def add_collision_object(self):
        p = PoseStamped()
        p.header.frame_id = self.robot1.get_planning_frame()
        p.pose.position.x = self.collision_object_pose[0][0] + 0.2
        p.pose.position.y = self.collision_object_pose[0][1]
        p.pose.position.z = self.collision_object_pose[0][2]
        p.pose.orientation.w = 1.0
        self.scene1.add_box("table", p, (0.15, 0.3, 0.2))

    def attach_collision_object(self):
        group_name = "arm"
        self.eef_link = "wrist_3_link"
        touch_links = ["wrist_3_link"]
        self.box_name = "table"
        print("touch_links====>",touch_links)
        self.scene1.attach_box(self.eef_link, self.box_name, touch_links=touch_links)

    def remove_collision_object(self):
        self.scene1.remove_attached_object(self.eef_link, name=self.box_name)
        rospy.sleep(1)
        # self.scene1.remove_world_object(self.box_name)
        # rospy.sleep(1)


if __name__ == "__main__":
    rospy.init_node('move_group_python1', anonymous=True)
    compute = GetIK()
    compute.detach()
    rospy.sleep(1)
    compute.move()
