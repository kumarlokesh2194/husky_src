import rospy
import numpy as np
import tf
import math
from pyquaternion import Quaternion
import rospy
import tf2_ros
import gazebo_msgs.msg
import geometry_msgs.msg
import time
import pdb

if __name__ == '__main__':
    index = 0
    index_husky = 0
    rospy.init_node('gazebo_tf_broadcaster')
    publisher = rospy.Publisher("pick_pose",geometry_msgs.msg.TransformStamped,queue_size = 1)
    transform = geometry_msgs.msg.TransformStamped()


    last_published = None
    def callback(data):
        global last_published
        transforms = []
        for i in range(0,len(data.name)):
            if data.name[i] == "modified_warehouse_clone_0_clone_0":
                index = i

                # transforms.append(transform)
                q_object = np.array([data.pose[index].orientation.x, data.pose[index].orientation.y, data.pose[index].orientation.z, data.pose[index].orientation.w])
                T_object = tf.transformations.quaternion_matrix(q_object)
                T_object[0:3,3] = np.array([data.pose[index].position.x, data.pose[index].position.y, data.pose[index].position.z])


            if data.name[i] == "husky1":
                index_husky = i
                q_husky = np.array([data.pose[index_husky].orientation.x, data.pose[index_husky].orientation.y, data.pose[index_husky].orientation.z, data.pose[index_husky].orientation.w])
                T_husky = tf.transformations.quaternion_matrix(q_husky)
                T_husky[0:3,3] = np.array([data.pose[index_husky].position.x, data.pose[index_husky].position.y, data.pose[index_husky].position.z])

                inverseT_husky = np.linalg.inv(T_husky)
                # print(T_husky)
                # print(inverseT_husky)

                T_object_base = np.matmul(inverseT_husky,T_object)
                # T_object_base = np.round(T_object_base,decimals = 4)
                print(T_object_base)
                in_quat_T_object_base = Quaternion(matrix = T_object_base)
                print("\n")
                print("---- in quat ----",in_quat_T_object_base)

        transform = geometry_msgs.msg.TransformStamped()
        transform.header.stamp = rospy.Time.now()
        transform.header.frame_id = "base_link"
        transform.child_frame_id = "modified_warehouse_clone_0_clone_0"
        transform.transform.translation.x = T_object_base[0][3]
        transform.transform.translation.y = T_object_base[1][3]
        transform.transform.translation.z = T_object_base[2][3]
        transform.transform.rotation.w = in_quat_T_object_base[0]
        transform.transform.rotation.x = in_quat_T_object_base[1]
        transform.transform.rotation.y = in_quat_T_object_base[2]
        transform.transform.rotation.z = in_quat_T_object_base[3]

        publisher.publish(transform)



    rospy.Subscriber("/gazebo/model_states", gazebo_msgs.msg.ModelStates, callback)

    rospy.spin()
