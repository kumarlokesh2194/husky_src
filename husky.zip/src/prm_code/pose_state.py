#!/usr/bin/env python

import rospy
from moveit_msgs.msg import MoveGroupActionResult
from moveit_msgs.msg import JointConstraint
import numpy as np

def callback(msg):
	points = msg.result.planned_trajectory.joint_trajectory.points
	print points[-1].positions
	#rospy.loginfo("goal position : {}".format(n))

def main():
	rospy.init_node("goal")
	rospy.Subscriber("husky1/move_group/result", MoveGroupActionResult,callback)
	rospy.spin()


if __name__=="__main__":
	main()
