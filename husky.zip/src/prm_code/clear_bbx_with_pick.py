import rospy
from std_msgs.msg import Bool
from octomap_msgs.srv import BoundingBoxQuery
from geometry_msgs.msg import PoseStamped, TransformStamped, Point
from octoload import OctoHandler

class ClearBbx():
    def __init__(self):
        self.bbx_min = Point()
        self.bbx_max = Point()
        self.husky_bbx_min = Point()
        self.husky_bbx_max = Point()
        self.flag = 0

    def min_max_coords(self,x,y,z):
        self.bbx_max.x = x + 0.5
        self.bbx_max.y = y + 0.2
        self.bbx_max.z = z + 0.3
        self.bbx_min.x = x - 0.5
        self.bbx_min.y = y - 0.2
        self.bbx_min.z = z - 0.3

    def min_max_husky_coords(self):
        self.husky_bbx_max.x = 0.5
        self.husky_bbx_max.y = 0.4
        self.husky_bbx_max.z = 0.7
        self.husky_bbx_min.x = -0.5
        self.husky_bbx_min.y = -0.4
        self.husky_bbx_min.z = 0.1
        self.bbx_clear_service.call(self.husky_bbx_min,self.husky_bbx_max)

    def clear_bbx(self,x,y,z):
        self.min_max_coords(x,y,z)
        OctoHandler(self.flag)
        self.bbx_clear_service = rospy.ServiceProxy('husky1/octomap_server/clear_bbx',BoundingBoxQuery)
        rospy.loginfo("Waiting for /clear_bbx service...")
        self.bbx_clear_service.wait_for_service()
        rospy.loginfo("Connected!")
        rospy.sleep(1)
        print(self.bbx_min,self.bbx_max)
        self.min_max_husky_coords()
        self.bbx_clear_service.call(self.bbx_min,self.bbx_max)
        OctoHandler(self.flag)
        rospy.sleep(1)
        self.flag = 1

if __name__ == '__main__':
    rospy.init_node("clear_box")
    run = ClearBbx()
    t1 = rospy.get_time()
    t2 = 0
    flag = 0
    rospy.sleep(.1)
    # while (t2-t1)<1:
    run.clear_bbx()
        # t2 = rospy.get_time()
