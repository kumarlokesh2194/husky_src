import rospy
from std_msgs.msg import Bool
from octomap_msgs.srv import BoundingBoxQuery
from geometry_msgs.msg import PoseStamped, TransformStamped, Point
from octoload import OctoHandler

class ClearBbx():
    def __init__(self):
        sub = rospy.Subscriber("min_max_cords",TransformStamped,self.callback)
        self.bbx_min = Point()
        self.bbx_max = Point()
        self.flag = 0

    def callback(self,msg):
        if msg.child_frame_id == "cube1_clone":
            self.bbx_max.x = msg.transform.translation.x + 0.1
            self.bbx_max.y = msg.transform.translation.y + 0.1
            self.bbx_max.z = msg.transform.translation.z + 0.1
            self.bbx_min.x = msg.transform.rotation.x - 0.1
            self.bbx_min.y = msg.transform.rotation.y - 0.1
            self.bbx_min.z = msg.transform.rotation.z - 0.1

    def clear_bbx(self):
        OctoHandler(self.flag)
        self.bbx_clear_service = rospy.ServiceProxy('husky1/octomap_server/clear_bbx',BoundingBoxQuery)
        rospy.loginfo("Waiting for /clear_bbx service...")
        self.bbx_clear_service.wait_for_service()
        rospy.loginfo("Connected!")
        print(self.bbx_min,self.bbx_max)
        self.bbx_clear_service.call(self.bbx_min,self.bbx_max)
        OctoHandler(self.flag)
        self.flag = 1

if __name__ == '__main__':
    rospy.init_node("clear_box")
    run = ClearBbx()
    t1 = rospy.get_time()
    t2 = 0
    flag = 0
    rospy.sleep(.1)
    # while (t2-t1)<1:
    run.clear_bbx()
        # t2 = rospy.get_time()
