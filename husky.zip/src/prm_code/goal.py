#!/usr/bin/env python

import rospy
from moveit_msgs.msg import MoveGroupActionGoal
from moveit_msgs.msg import JointConstraint
import numpy as np

def callback(msg):
	n = []
	position = msg.goal.request.goal_constraints
	for i in position:
		for j in i.joint_constraints:	
			n.append(j.position)
	print(n)
	#rospy.loginfo("goal position : {}".format(n))

def main():
	rospy.init_node("goal")
	rospy.Subscriber("husky1/move_group/goal", MoveGroupActionGoal,callback)
	rospy.spin()


if __name__=="__main__":
	main()
