#! /usr/bin/env python

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from geometry_msgs.msg import PoseStamped
from math import pi


def move():
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('move_group_python1', anonymous=True)

    robot1 = moveit_commander.RobotCommander(robot_description = "husky1/robot_description")
    scene1 = moveit_commander.PlanningSceneInterface("husky1")
    group1 = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = "arm")
    joint_goal = [-0.3533597973854394, -0.624947511239454, 0.6731429152374906, 3.0942885703935725, -1.1977332174174489, -0.04722468307831788]
    group1.go(joint_goal, wait=True)



    rospy.sleep(10)

    moveit_commander.roscpp_shutdown()

if __name__ == '__main__':
    move()
# -1.22,-3.48   #0.431,-3.46, yaw=-1.57  #quat = 0,0,-0.707,707
 #7.89,-0.527,3.14  #quat = 0,0,1,0
