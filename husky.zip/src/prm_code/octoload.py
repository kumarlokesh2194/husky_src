#! /usr/bin/env python

import rospy
from octomap_msgs.msg import Octomap
from moveit_msgs.msg import PlanningScene, PlanningSceneWorld
from actionlib_msgs.msg import GoalStatusArray

class OctoHandler():
	mapMsg1=None
	mapMsg2=None

	def __init__(self,flag):
		self.flag = flag
		# rospy.init_node("moveit_octomap_handler_1")
		rospy.Subscriber("husky1/octomap_full", Octomap, self.cb1)
		#rospy.Subscriber("husky2/octomap_full", Octomap, self.cb2, queue_size=1)
		self.pub = rospy.Publisher("husky1/move_group/monitored_planning_scene", PlanningScene, queue_size=20)
		#pub2 = rospy.Publisher("husky2/move_group/monitored_planning_scene", PlanningScene, queue_size=1)
		self.pub2 = rospy.Publisher("husky1/planning_scene", PlanningScene, queue_size=20)
		# rospy.Subscriber("husky1/move_base/status",GoalStatusArray,self.rrt_status_callback)
		rospy.sleep(2)
		self.pub_octo_to_scene()


	def cb1(self, msg):
		psw = PlanningSceneWorld()
		psw.octomap.header.stamp = rospy.Time.now()
		psw.octomap.header.frame_id = "husky1/base_link"
		psw.octomap.octomap = msg
		psw.octomap.origin.position.x = 0
		psw.octomap.origin.orientation.w = 1
		ps = PlanningScene()
		ps.world = psw
  		ps.is_diff = True
		self.mapMsg1 = ps

	def pub_octo_to_scene(self):
		if (self.mapMsg1 is not None) and self.flag == 0:
			self.pub.publish(self.mapMsg1)
			self.pub2.publish(self.mapMsg1)
		else:
			pass

if __name__ == "__main__":
	octomap_object = OctoHandler()
