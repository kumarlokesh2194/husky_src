#!/usr/bin/env python

import rospy
from moveit_msgs.srv import GetPositionIK
from moveit_msgs.srv import GetPositionIKRequest
from moveit_msgs.srv import GetPositionIKResponse
from geometry_msgs.msg import PoseStamped, TransformStamped
import geometry_msgs
import moveit_commander
import sys
from moveit_msgs.msg import RobotState
from geometry_msgs.msg import Transform, PoseStamped
from sensor_msgs.msg import JointState
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from geometry_msgs.msg import PoseStamped
from math import pi
from gazebo_ros_link_attacher.srv import Attach, AttachRequest, AttachResponse
from octomap_msgs.srv import BoundingBoxQuery
from geometry_msgs.msg import Twist


class GetIK:
    def __init__(self, group="arm", ik_timeout=2.0, ik_attempts=50,
                 avoid_collisions=False):

        rospy.loginfo("Initalizing GetIK...")
        self.object_pose = []
        rospy.Subscriber("pick_pose",TransformStamped,self.callback_pose,queue_size = 1)
        self.pose_target = PoseStamped()
        self.group_name = group
        self.ik_timeout = ik_timeout
        self.ik_attempts = ik_attempts
        self.avoid_collisions = avoid_collisions
        rospy.loginfo("Computing IKs for group: " + self.group_name)
        rospy.loginfo("With IK timeout: " + str(self.ik_timeout))
        rospy.loginfo("And IK attempts: " + str(self.ik_attempts))
        rospy.loginfo("Setting avoid collisions to: " +
                      str(self.avoid_collisions))
        self.ik_srv = rospy.ServiceProxy('husky1/compute_ik',
                                         GetPositionIK)
        rospy.loginfo("Waiting for /compute_ik service...")
        self.ik_srv.wait_for_service()
        rospy.loginfo("Connected!")
        self.bbx_clear_service = rospy.ServiceProxy('husky1/octomap_server/clear_bbx',BoundingBoxQuery)
        rospy.loginfo("Waiting for /clear_bbx service...")
        self.bbx_clear_service.wait_for_service()
        rospy.loginfo("Connected!")


    def callback_pose(self,msg):
        # self.pose_target = msg
        if msg.child_frame_id == "cube1_clone": #modified_warehouse_clone_0_clone_0" #modified_warehouse_clone_0_clone_0_clone_clone_clone_clone_clone_clone_0
            self.pose_target.header.frame_id = "base_link"
            self.pose_target.pose.orientation.w = 0.7071068
            self.pose_target.pose.orientation.x = 0
            self.pose_target.pose.orientation.y = 0
            self.pose_target.pose.orientation.z = -0.7071068
            self.pose_target.pose.position.x = msg.transform.translation.x - 0.4
            self.pose_target.pose.position.y = msg.transform.translation.y
            self.pose_target.pose.position.z = msg.transform.translation.z

    def get_ik(self,
               group=None,
               ik_timeout=None,
               ik_attempts=None,
               avoid_collisions=True):

        tf = JointState()
        rs = RobotState()

        tf.name = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']
        tf.position =  [0,0,0,0,0,0]
        tf.header.frame_id = "base_link"
        rs.joint_state = tf
        print(self.pose_target)
        if group is None:
            group = self.group_name
        if ik_timeout is None:
            ik_timeout = self.ik_timeout
        if ik_attempts is None:
            ik_attempts = self.ik_attempts
        if avoid_collisions is None:
            avoid_collisions = self.avoid_collisions
        req = GetPositionIKRequest()
        req.ik_request.group_name = group
        req.ik_request.pose_stamped = self.pose_target
        req.ik_request.timeout = rospy.Duration(ik_timeout)
        req.ik_request.attempts = ik_attempts
        req.ik_request.avoid_collisions = avoid_collisions
        req.ik_request.robot_state = rs
        # req.ik_request.robot_state.is_diff = True

        try:
            resp = self.ik_srv.call(req)
            # print resp
            i_1, i_2, i_3, i_4, i_5, i_6 = 0,0,0,0,0,0
            if resp.error_code.val == 1:
                goal_samples = []
                for i in range(0,len(resp.solution.joint_state.name)):
                    if resp.solution.joint_state.name[i] == "shoulder_pan_joint":
                        i_1 = i
                    elif resp.solution.joint_state.name[i] == "shoulder_lift_joint":
                        i_2 = i
                    elif resp.solution.joint_state.name[i] == "elbow_joint":
                        i_3 = i
                    elif resp.solution.joint_state.name[i] == "wrist_1_joint":
                        i_4 = i
                    elif resp.solution.joint_state.name[i] == "wrist_2_joint":
                        i_5 = i
                    elif resp.solution.joint_state.name[i] == "wrist_3_joint":
                        i_6 = i

                position = resp.solution.joint_state.position
                print(resp)
                goal_samples.append([position[i_1],position[i_2],position[i_3],position[i_4],position[i_5],position[i_6]])
                print("<----- computed joint_state  ----->")
                print(goal_samples)
            return goal_samples


        except rospy.ServiceException as e:
            rospy.logerr("Service exception: " + str(e))
            resp = GetPositionIKResponse()
            resp.error_code = 99999  # Failure

    def attach(self):
        #rospy.init_node('demo_attach_links')
        rospy.loginfo("Creating ServiceProxy to /link_attacher_node/attach")
        attach_srv = rospy.ServiceProxy('/link_attacher_node/attach',
                                        Attach)
        attach_srv.wait_for_service()
        rospy.loginfo("Created ServiceProxy to /link_attacher_node/attach")

        # Link them
        rospy.loginfo("Attaching cube1 and cube2")
        req = AttachRequest()
        req.model_name_1 = "husky1"
        req.link_name_1 = "wrist_3_link"
        req.model_name_2 = "cube3"
        req.link_name_2 = "link"

        attach_srv.call(req)


    def detach(self):
        #rospy.init_node('demo_detach_links')
        rospy.loginfo("Creating ServiceProxy to /link_attacher_node/detach")
        attach_srv = rospy.ServiceProxy('/link_attacher_node/detach',
                                        Attach)
        attach_srv.wait_for_service()
        rospy.loginfo("Created ServiceProxy to /link_attacher_node/detach")

        # Link them
        #rospy.loginfo("Detaching cube1 and cube2")
        req = AttachRequest()
        req.model_name_1 = "husky1"
        req.link_name_1 = "wrist_3_link"
        req.model_name_2 = "cube1_clone"
        req.link_name_2 = "link"

        attach_srv.call(req)


    def move(self):
        moveit_commander.roscpp_initialize(sys.argv)
        rospy.init_node('move_group_python1', anonymous=True)

        self.robot1 = moveit_commander.RobotCommander(robot_description = "husky1/robot_description")
        self.scene1 = moveit_commander.PlanningSceneInterface("husky1")
        self.group1 = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = "arm")
        # group2 = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = "gripper")

        joint_goal = [2.8679971107859212, -0.021237496915359252, 0.3348694686768484, -1.887715811116879, -1.5042659159617278, -0.24017760979990443]
        self.group1.go(joint_goal, wait=True)
        rospy.sleep(0.5)
        self.detach()
        self.remove_collision_object()
        rospy.sleep(3)


        moveit_commander.roscpp_shutdown()

    def add_collision_object(self):
        p = PoseStamped()
        p.header.frame_id = self.robot1.get_planning_frame()
        p.pose.position.x = 0.596 + 0.32
        p.pose.position.y = -0.0709
        p.pose.position.z = 0.843
        p.pose.orientation.w = 1.0
        self.scene1.add_box("table", p, (0.4, 0.6, 0.4))

    def attach_collision_object(self):
        group_name = "arm"
        self.eef_link = "wrist_3_link"
        touch_links = ["wrist_3_link"]
        self.box_name = "table"
        print("touch_links====>",touch_links)
        self.scene1.attach_box(self.eef_link, self.box_name, touch_links=touch_links)
        # object(3)

    def remove_collision_object(self):
        self.scene1.remove_attached_object(self.eef_link, name=self.box_name)
        self.scene1.remove_world_object(self.box_name)
        # object(5)

    # def object(self,timeout):
    # 	start = rospy.get_time()
    # 	seconds = rospy.get_time()
    # 	while (seconds - start < timeout) and not rospy.is_shutdown():
    # 	  # Test if the box is in attached objects
    # 	  attached_objects = scene.get_attached_objects([box_name])
    # 	  is_attached = len(attached_objects.keys()) > 0
    # 	  is_known = box_name in scene.get_known_object_names()
    # 	  rospy.sleep(0.1)
    # 	  seconds = rospy.get_time()
    #
    # 	# If we exited the while loop without returning then we timed out
    # 	return False



if __name__ == "__main__":
    rospy.init_node('move_group_python1', anonymous=True)
    compute = GetIK()
    # compute.move()
    compute.attach()
    publisher = rospy.Publisher("husky1/cmd_vel",Twist,queue_size = 10)
    pub = Twist()
    t1 = rospy.get_time()
    t2 = 0
    pub.linear.x = -0.3
    while (t2-t1)<1.5:
        publisher.publish(pub)
        t2 = rospy.get_time()
