#! /usr/bin/env python

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from geometry_msgs.msg import PoseStamped, Pose
from math import pi
from trajectory_msgs.msg import JointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from std_msgs.msg import Header
from numpy import array
import time
from numpy import array


def move():
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('add_collision_object', anonymous=True)


    robot1 = moveit_commander.RobotCommander(robot_description = "husky1/robot_description")
    scene1 = moveit_commander.PlanningSceneInterface("husky1")
    # group1 = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = "arm")
    # group2 = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = "gripper")

    rospy.sleep(2)
    p = PoseStamped()
    p.header.frame_id = robot1.get_planning_frame()
    p.pose.position.x = 0.596 + 0.32
    p.pose.position.y = -0.0709
    p.pose.position.z = 0.843
    p.pose.orientation.w = 1.0
    scene1.add_box("table", p, (0.4, 0.6, 0.4))



    moveit_commander.roscpp_shutdown()

if __name__ == '__main__':
    time_taken = 0
    flag = 1
    move()
    r = rospy.Rate(1)
    while not rospy.is_shutdown():
        r.sleep()
