#! /usr/bin/env python

import rospy
import numpy as np
import tf
import math
from pyquaternion import Quaternion
import gazebo_msgs.msg
import geometry_msgs.msg
import time
import pdb
import csv


def callback(data):
    T_object_base = []
    row = []
    global last_published
    transforms = []
    for index in range(0,len(data.name)):
        q_object = np.array([data.pose[index].orientation.x, data.pose[index].orientation.y, data.pose[index].orientation.z, data.pose[index].orientation.w])
        T_object = tf.transformations.quaternion_matrix(q_object)
        T_object[0:3,3] = np.array([data.pose[index].position.x, data.pose[index].position.y, data.pose[index].position.z])

        for i in range(0,len(data.name)):
            # print(data.name)
            if data.name[i] == "husky1":
                index_husky = i
                q_husky = np.array([data.pose[index_husky].orientation.x, data.pose[index_husky].orientation.y, data.pose[index_husky].orientation.z, data.pose[index_husky].orientation.w])
                T_husky = tf.transformations.quaternion_matrix(q_husky)
                T_husky[0:3,3] = np.array([data.pose[index_husky].position.x, data.pose[index_husky].position.y, data.pose[index_husky].position.z])

                inverseT_husky = np.linalg.inv(T_husky)
                # print(T_husky)
                # print(inverseT_husky)

                T_object_base = np.matmul(inverseT_husky,T_object)
                # print(T_object_base)
                in_quat_T_object_base = Quaternion(matrix = T_husky)
                # print("\n")
                # print("---- in quat ----",in_quat_T_object_base)

                transform = geometry_msgs.msg.TransformStamped()
                transform.header.stamp = rospy.Time.now()
                transform.header.frame_id = "base_link"
                transform.child_frame_id = data.name[index]
                transform.transform.translation.x = T_object_base[0][3]
                transform.transform.translation.y = T_object_base[1][3]
                transform.transform.translation.z = T_object_base[2][3]
                transform.transform.rotation.w = in_quat_T_object_base[0]
                transform.transform.rotation.x = in_quat_T_object_base[1]
                transform.transform.rotation.y = in_quat_T_object_base[2]
                transform.transform.rotation.z = in_quat_T_object_base[3]

                min_max = geometry_msgs.msg.TransformStamped()

                bbx_x_min = T_object_base[0][3] + 0.3
                bbx_y_min = T_object_base[1][3] + 0.2
                bbx_z_min = T_object_base[2][3] + 0.2

                bbx_x_max = T_object_base[0][3] - 0.3
                bbx_y_max = T_object_base[1][3] - 0.2
                bbx_z_max = T_object_base[2][3] - 0.2

                min_max.header.stamp = rospy.Time.now()
                min_max.header.frame_id = "base_link"
                min_max.child_frame_id = data.name[index]
                min_max.transform.translation.x = bbx_x_min
                min_max.transform.translation.y = bbx_y_min
                min_max.transform.translation.z = bbx_z_min
                min_max.transform.rotation.w = 1
                min_max.transform.rotation.x = bbx_x_max
                min_max.transform.rotation.y = bbx_y_max
                min_max.transform.rotation.z = bbx_z_max

                publisher_1.publish(min_max)


                publisher.publish(transform)

if __name__ == '__main__':
    index_husky = 0
    rospy.init_node('gazebo_broadcaster')
    publisher = rospy.Publisher("pick_pose",geometry_msgs.msg.TransformStamped,queue_size = 1)
    publisher_1 = rospy.Publisher("min_max_cords",geometry_msgs.msg.TransformStamped,queue_size = 1)
    rospy.Subscriber("/gazebo/model_states", gazebo_msgs.msg.ModelStates, callback)
    transform = geometry_msgs.msg.TransformStamped()
    while not rospy.is_shutdown():
        rospy.spin()
