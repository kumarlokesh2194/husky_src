#! /usr/bin/env python

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from geometry_msgs.msg import PoseStamped
from math import pi
from gazebo_ros_link_attacher.srv import Attach, AttachRequest, AttachResponse
from compute_ik import GetIK

def attach():
    #rospy.init_node('demo_attach_links')
    rospy.loginfo("Creating ServiceProxy to /link_attacher_node/attach")
    attach_srv = rospy.ServiceProxy('/link_attacher_node/attach',
                                    Attach)
    attach_srv.wait_for_service()
    rospy.loginfo("Created ServiceProxy to /link_attacher_node/attach")

    # Link them
    rospy.loginfo("Attaching cube1 and cube2")
    req = AttachRequest()
    req.model_name_1 = "husky2"
    req.link_name_1 = "robotiq_85_left_finger_tip_link"
    req.model_name_2 = "cube1_clone"
    req.link_name_2 = "link"

    attach_srv.call(req)
    # From the shell:
    """
rosservice call /link_attacher_node/attach "model_name_1: 'cube1'
link_name_1: 'link'
model_name_2: 'cube2'
link_name_2: 'link'"
    """

    #rospy.loginfo("Attaching cube2 and cube3")
    #req = AttachRequest()
    #req.model_name_1 = "husky1"
    #req.link_name_1 = "robotiq_85_right_finger_tip_link"
    #req.model_name_2 = "cube1"
    #req.link_name_2 = "link"

    #attach_srv.call(req)

    #rospy.loginfo("Attaching cube3 and cube1")
    #req = AttachRequest()
    #req.model_name_1 = "cube3"
    #req.link_name_1 = "link"
    #req.model_name_2 = "cube1"
    #req.link_name_2 = "link"

    #attach_srv.call(req)

def detach():
    #rospy.init_node('demo_detach_links')
    rospy.loginfo("Creating ServiceProxy to /link_attacher_node/detach")
    attach_srv = rospy.ServiceProxy('/link_attacher_node/detach',
                                    Attach)
    attach_srv.wait_for_service()
    rospy.loginfo("Created ServiceProxy to /link_attacher_node/detach")

    # Link them
    #rospy.loginfo("Detaching cube1 and cube2")
    req = AttachRequest()
    req.model_name_1 = "husky2"
    req.link_name_1 = "robotiq_85_left_finger_tip_link"
    req.model_name_2 = "cube1_clone"
    req.link_name_2 = "link"

    attach_srv.call(req)
    # From the shell:
    """
rosservice call /link_attacher_node/detach "model_name_1: 'cube1'
link_name_1: 'link'
model_name_2: 'cube2'
link_name_2: 'link'"
    """

    rospy.loginfo("Attaching cube2 and cube3")
    req = AttachRequest()
    req.model_name_1 = "/"
    req.link_name_1 = "robotiq_85_right_finger_tip_link"
    req.model_name_2 = "cube1"
    req.link_name_2 = "link"

    attach_srv.call(req)

    #rospy.loginfo("Attaching cube3 and cube1")
    #req = AttachRequest()
    #req.model_name_1 = "cube3"
    #req.link_name_1 = "link"
    #req.model_name_2 = "cube1"
    #req.link_name_2 = "link"

    #attach_srv.call(req)



def move():
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('move_group_python1', anonymous=True)

    robot1 = moveit_commander.RobotCommander(robot_description = "husky1/robot_description")
    scene1 = moveit_commander.PlanningSceneInterface("husky1")
    group1 = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = "arm")
    group2 = moveit_commander.MoveGroupCommander(robot_description = "husky1/robot_description", ns = "husky1", name = "gripper")


    joint_goal = [2.4806584403294383, 2.3886176385444426, -1.8768119340865135, -0.6700573894561577, 2.167451807752827, -0.11369938276991551]
    group1.go(joint_goal, wait=True)

    rospy.sleep(10)

    joint_goal = [-1.0262135039446911, 1.9814910576997107, -1.7647401431579897, -0.09105033052708025, -1.040202930658614, -0.1405339069395137]
    group1.go(joint_goal, wait=True)

    rospy.sleep(10)

    joint_goal = [-1.8525822035356005, 2.9105368552557858, -1.2335206574122202, -1.8916488448059887, 0.6455932024948663, 0.2019660074946524]
    group1.go(joint_goal, wait=True)

    rospy.sleep(10)


    joint_goal = [-2.8088950224852307, 1.7185947003871724, -0.16107741147314783, -2.0951737640035537, 1.3081508022708372, 0.13979047713086573]
    group1.go(joint_goal, wait=True)

    rospy.sleep(10)

    moveit_commander.roscpp_shutdown()

if __name__ == '__main__':
    move()
