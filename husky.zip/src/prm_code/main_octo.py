#! /usr/bin/env python

import rospy
from octomap_msgs.msg import Octomap
from moveit_msgs.msg import PlanningScene, PlanningSceneWorld
from actionlib_msgs.msg import GoalStatusArray
from clear_bbx import ClearBbx
from octoload import OctoHandler
from std_srvs.srv import Empty

class OctoMain():

    def __init__(self):
        rospy.init_node("moveit_octomap_handler_1")
        rospy.Subscriber("husky1/move_base/status",GoalStatusArray,self.rrt_status_callback)
        self.clear_octomap_srv = rospy.ServiceProxy("husky1/clear_octomap",Empty)
        self.status = 0
        self.call_flag = 0

    def rrt_status_callback(self,msg):
        if msg is None:
            rospy.loginfo("waiting for rrt to get called")
        self.status = msg.status_list[0].status

    def run_logic(self):
        if self.status == 1:
            rospy.loginfo("initialized rrt moving towards goal")
        elif self.status == 3 and self.call_flag == 0:
            clear = ClearBbx()
            clear.clear_bbx()
            self.call_flag = 1
            print("##################################")
            rospy.sleep(10)
            self.clear_octomap_srv.call()


if __name__ == "__main__":
    octomap_object = OctoMain()
    t1 = rospy.get_time()
    t2 = 0
    flag = 0
    rospy.sleep(.1)
    while (t2-t1)<10:
        octomap_object.run_logic()
        t2 = rospy.get_time()
